leuk = data.frame(
  time = c(1, 1, 2, 2, 3, 4, 4, 5, 5, 8, 8, 8, 8, 11, 11, 12, 12, 15, 17, 22, 23, 6,
              6, 6, 6, 7, 9, 10, 10, 11, 13, 16, 17, 19, 20, 22, 23, 25, 32, 32, 34, 35),
  event = c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0),
  group = c("placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo","placebo",
            "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP", "drug-6-MP")
)

  leuk$trt = 0*(leuk$group=="placebo")+1*(leuk$group=="drug-6-MP")

