#' Approximate predictive individual effect distribution
#'
#' @param n.sim number of simulations used for the
#' predictive individual effect distribution; if zero,
#' the distribution will be obtained as sort(x1)-sort(x2), assuming
#' that x1 and x2 are realizations from the predictive distribution
#' of group 1 and 2, respectively
#' @param x1 m1-vector of observations or predictions for group 1
#' @param x2 m2-vector of observations or predictions for group 2
#' @param cpdf1 cumulative predictive distribution values for x1;
#' if not given, the values 1/(m1+1),...,m1/(m1+1) will be used
#' @param cpdf2 cumulative predictive distribution values for x1
#' if not given, the values 1/(m2+1),...,m2/(m2+1) will be used
#' @param low lower data boundary (default is "-Inf")
#' @param up upper data boundary (default is "+Inf")
#' @param probs probabilities for distribution summaries;
#' default is the 2.5%, 50% (median), and 97.5% percentile
#' @param cutoffs threshold values for summaries of the predictive individual effect distribution
#' @param sim.save logical; if \code{TRUE}, the simulated valus for
#' the group 1 and group 2 predictions will be saved. Default is \code{FALSE}
#'
#' @return sim: simulated predictions for group 1 and 2
#' @return marg: summaries of the marginal predictions for group 1 and 2
#' @return pie: summary of the predictive individual effect distribution
#'
#' @examples
#' x1 = rnorm(2000,0.5,1)
#' x2 = rnorm(2000,0,1)
#' a1 = pie_x12(n.sim = 1e5,x1=x1,x2=x2)
#' a2 = pie_x12(n.sim = 0,x1=x1,x2=x2)
#' print(rbind(a1$pie,a2$pie))
#'
pie_x12 =function(
           n.sim,
           x1,
           x2,
           cpdf1=NULL,
           cpdf2=NULL,
           low = -Inf,
           up = +Inf,

           probs=c(0.025,0.5,0.975),
           cutoffs=0,
           sim.save=FALSE) {

  if (missing(n.sim))
    stop("Number of simulatios *n.sim* is missing.
  if 0, no simulations will be performed:
  the pie distribution will be otained as sort(x1)-sort(x2)")

  n1 = length(x1); n2 = length(x2)

  if (is.null(cpdf1)) {
    x1 = sort(x1)
    cpdf1 = (1:n1)/(n1+1);
  }

  if (is.null(cpdf2)) {
    x2 = sort(x2)
    cpdf2 = (1:n2)/(n2+1);
  }

  if (any(order(x1) != order(cpdf1)))
    stop("The ordering of x1 and cpdf1 are inconsistent")

  if (any(order(x2) != order(cpdf2)))
    stop("The ordering of x2 and cpdf2 are inconsistent")


  if (n.sim>0) {
    u = runif(n.sim)
    u = sort(u)

    if (low == -Inf & up == +Inf) {
      xx1 = 1/(1+exp(-x1))
      xx2 = 1/(1+exp(-x2))

      pred1 = approx(x=c(0,cpdf1,1),y=c(0,xx1,1),xout=u,yleft=0,yright=1)$y
      pred2 = approx(x=c(0,cpdf2,1),y=c(0,xx2,1),xout=u,yleft=0,yright=1)$y

      pred1 = log(pred1)-log(1-pred1)
      pred2 = log(pred2)-log(1-pred2)
    }

    if (low == 0 & up == +Inf) {
      # xx1 = 1-exp(-x1)
      # xx2 = 1-exp(-x2)
      xx1 = x1/(1+x1)
      xx2 = x2/(1+x2)

      pred1 = approx(x=c(0,cpdf1,1),y=c(0,xx1,1),xout=u,yleft=0,yright=1)$y
      pred2 = approx(x=c(0,cpdf2,1),y=c(0,xx2,1),xout=u,yleft=0,yright=1)$y

      pred1 = pred1/(1-pred1)
      pred2 = pred2/(1-pred2)
    }

    if (low > -Inf & up < +Inf) {

      pred1 = approx(x=c(0,cpdf1,1),y=c(low,x1,up),xout=u,yleft=low,yright=up)$y
      pred2 = approx(x=c(0,cpdf2,1),y=c(low,x2,up),xout=u,yleft=low,yright=up)$y
    }

    if (sim.save)
      sim = list(pred0=pred0,pred1=pred)
    else
      sim = NULL

    marg1 =sim_sum(pred1,probs=probs)
    marg2 =sim_sum(pred2,probs=probs)
    marg = list(marg1=marg1,marg2=marg2)
  }

  if (n.sim == 0 & (length(x1)!=length(x2)))
    stop("x1 and x2 must be of same length for *n.sim=0*")

  if (n.sim == 0 & (length(x1)==length(x2))) {
    sim="no simulations: pie distribution was obtained
    as sort(x1)-sort(x2)"
    pred1 = sort(x1)
    pred2 = sort(x2)
    marg1 =sim_sum(pred1,probs=probs)
    marg2 =sim_sum(pred2,probs=probs)
    marg = list(marg1=marg1,marg2=marg2)
  }

  pie = sim_sum(pred1-pred2,probs=probs,cutoffs=cutoffs)

  return(list(sim=sim,marg=marg,pie=pie))
}
