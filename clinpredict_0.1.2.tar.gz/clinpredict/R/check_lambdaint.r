#' Checks compatibility of dimensions for hazard parameters and interval boundaries
#'
#' @param lambda an \code{n.int}-vector or \code{sxn.int} matrix of interval hazards
#' @param int an \code{n.int-1}-vector of interval boundaries
#'
check_lambdaint = function( lambda, int) {

#  if (is.vector(lambda)) {
    if (!is.matrix(lambda)) {
      if (length(lambda) != (length(int)+1))
      stop("length of *lambda* must be *n.int*; length of *int* must be *n.int-1*")
  }

  if (is.matrix(lambda)) {
    if (ncol(lambda) != length(int)+1)
      stop("number of columns of *lambda* must be *n.int*; length of *int* must be *n.int-1*")
  }
  return(NULL)
}
