#' Summaries of non-parametric predictive distribution for survival data by Berliner-Hill
#'
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators, 1 for events and 0 for censored observations. If \code{NULL},
#' no censoring is assumed
#' @param probs probabilities for which quantiles will be obtained; default is median and 95%-interval
#' @param version original version ("BerlinerHill") or modified version ("pwgammaexp")
#'
#'
#' @examples
#' spredsurv(time=km$time,event=km$event)
#' # compare to prediction via simulation
#' pred = rpredsurv(1e5,time=km$time,event=km$event)
#' sim_sum(pred)
#'
spredsurv= function(time,event=NULL,probs=c(0.025,0.5,0.975),
                     version=c("BerlinerHill","pwgammaexp")[2])
                      {
  aa = cpdfsurv(time,event,version=version)


  if (version=="BerlinerHill")
    x = spwexp(aa$lambda,aa$int,probs=probs)

  if (version=="pwgammaexp")
    x = spwgammaexp(aa$a,b=aa$b,int=aa$int,probs=probs)

  rownames(x) = NULL
    return(x)
}
