#' Density of gamma-gamma distribution
#'
#' gamma-gamma distribution is
#' the predictive distribution for the sum of n exponential distributions
#' for which the hazard follows a Gamma(a,b) distribution
#' lambda ~ gamma(a,b), X_1,...,X_n | lambda ~ exp(lambda),
#' Y = sum(X_i), Y ~ gamma-gamma(n,a,b)
#'
#' @param x vector of values for which the density will be computed
#' @param n,a,b parameters of gamma distribution
#'
#' @examples
#' # density of gamma distribution and gamma-exponential distribution with same mean
#' a=2; b=4;
#' x = seq(0,10,length=100000);
#' plot(x,dgamma(x,5,a/b),type="l",lty=1,ylab="density")
#' lines(x,dgammagamma(x,n=5,a,b),lty=2)
#'
dgammagamma <- function(x,n, a, b) {
  logd <- a*log(b) +(n-1)*log(x)+lgamma(a+n)-lgamma(a)-lgamma(n)-(a+n)*log(b+x)
  return(exp(logd))
}





