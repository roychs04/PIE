#' Transformation of individual patient data (IPD) to interval data
#'
#' @param obstime n-vector of observation (event or censoring) times
#' @param event n-vector of event indicators: 1 for event, 0 for censoring
#' @param x \code{nxk} covariate matrix (\code{NULL} for no covariates)
#' @param int vector of interval boundaries; if missing, interval boundaries are set
#' at event times
#'
#' @return dataframe with interval indices, interval boundaries, number of subjects at risk,
#' exposure time, number of events, and estimated hazards
#'
#' @examples
#'
#' data(leuk)
#'
#' int = c(5,10,20)
#' ipd2int(leuk$obstime,leuk$event,x=subset(leuk,select="trt"),int=int)
#'
#' # interval data set, interval boundaries at event times
#' ipd2int(leuk$obstime,leuk$event,x=subset(leuk,select="trt"))
#'
ipd2int = function(obstime, event, x=NULL,int=NULL) {

  if (!is.null(x)) {
    nms.x = names(as.data.frame(x))
  }

  if (is.null(int)) {
    int = obstime[event==1]
    int = sort(unique(int))
    int = int[-length(int)]
  }

  int = c(int,1e100)
  n.int = length(int)

  nocov = FALSE
  if (is.null(x)) {
    nocov = TRUE
    x = rep(0, length(obstime))
    nms.x = "0"
  }
  if (!is.matrix(x))
    x = cbind(x)

  ncov = ncol(x)


  #if (is.null(colnames(x)))
  if (is.null(nms.x))
    colnames(x) = paste("x", 1:ncov,sep="")

    ds = data.frame(x, obstime, event)

    xxpat = NULL
    for (j in 1:length(obstime)) {
      xxpat1 = paste(x[j, 1:ncov], collapse = "/")
      xxpat = c(xxpat, xxpat1)
    }
    ds$xpat = xxpat
    xxpat = unique(xxpat)

  int0 = c(0, int)

  # interval index
  ds$int.i = sapply(ds$obstime, function(e)
    sum(e > int0))

  int.len = diff(int0)
  int.names = paste("(", int0[1:n.int], ",", int0[2:(n.int + 1)], "]", sep ="")


  # create interval data
  ds.list.i = lapply(1:n.int, function(e)
    ds[ds$int.i >= e, ])


  ds.group = list()
  # at risk data for each interval
  for (j in 1:n.int) {
    dds = ds.list.i[[j]]
    dds$event = dds$event * (dds$int.i == j)
    dds$exptime = (dds$obstime - int0[j]) * (dds$int.i == j) + int.len[j] *
      (dds$int.i > j)
    ds.group[[j]] = dds
  }

  ds.out = NULL
  for (jj in 1:n.int) {
    dsex = ds.group[[jj]]

    xxx = NULL
    for (j in 1:length(xxpat)) {
        sel = (dsex$xpat == xxpat[j])

        if (length(sel) > 0 & sum(sel)>0 ) {
          x1 = dsex[sel, , drop = FALSE]
          xx1 = c(
          x = x1[1, 1:ncov],
          int.i = jj,
          exptime = sum(x1$exptime),
          event = sum(x1$event),
          atrisk = nrow(x1)
        )
      }
        if (length(sel) == 0 | sum(sel)==0)  {
        xx1 = c(x=x[ds$xpat==xxpat[j],,drop=FALSE][1,],int.i=jj,exptime=0,event=0,atrisk=0)
      }
      xxx = rbind(xxx, xx1)
    }
    ds.out = rbind(ds.out, xxx)
    colnames(ds.out)[1:ncov] = nms.x
    rownames(ds.out) = NULL
  }

  if (nocov)
    x = NULL
  else {
    x = ds.out[, 1:ncov,drop=FALSE]
    colnames(x) = nms.x
  }

  ds.out = as.matrix(ds.out)

  intindex = unlist(ds.out[,"int.i"])
  intlow = int0[intindex]
  inthigh = int0[intindex+1]
  atrisk = unlist(ds.out[,"atrisk"])
  exptime = unlist(ds.out[, "exptime"])
  nevents = unlist(ds.out[, "event"])

  ds = data.frame(
    intindex,
    intlow,
    inthigh,
    atrisk,
    exptime,
    nevents,
    haz = nevents/exptime
  )

    ds$inthigh[ds$inthigh==1e100] = Inf
  if (!is.null(x))
    ds = cbind(ds,x)

     return(    ds = ds  )
 }

