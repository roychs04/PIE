#' Density of gamma-exponential distribution
#'
#' gamma-exponential (overdispersed exponential) distribution:
#' lambda ~ gamma(a,b), Y | lambda ~ exp(lambda), Y ~ gamma-exponential(a,b)
#'
#' @param x vector of values for which the density will be computed
#' @param a,b parameters of gamma distribution
#'
#' @examples
#'
#' # density of gamma distribution and gamma-exponential distribution with same mean
#' a=2; b=1;
#' x = seq(0,2,length=1000);
#' # exponential distribution with same mean
#' plot(x,dexp(x,a/b),type="l");
#' # overdispersed gamma-exponential version
#' lines(x,dgammaexp(x,a,b),lty=2)
#'
dgammaexp <- function(x, a, b) {
  logd <- log(a) + a * log(b) - (a + 1) * log(b + x)
  return(exp(logd))
}





