#' Density of gamma-poisson distribution
#'
#' gamma-poisson (overdispersed Poisson) distribution:
#' lambda ~ gamma(a,b), Y | lambda ~ poisson(lambda x E), Y ~ gamma-poisson(E,a,b)
#'
#' @param r number of successes; a scalar or vector
#' @param E exposure time (sample size); a scalar or vector
#' @param a,b parameters of gamma distribution
#'
#' @examples
#' dgp = dgammapoisson( 0:10, 4, 1, 1)
#' print(dgp)
#'
dgammapoisson <- function(r, E, a, b) {
  p <-
    a * log(b) - lgamma(a) + lgamma(a + r) - lgamma(r + 1) + r * log(E) - (a +
                                                                             r) * log(b + E)
  d = exp(p)
  return(d)
}


