
#' Non-parametric cumulative predictive distribution function (sHill)
#'
#' @param x data vector
#'
#'
#' @examples
#' x = c(1,4,5,12)
#' cpdf(x)
#'
#' #Example with ties: note that continuous data are assumed, ties are resolved
#' #by adding small random numbers for ties
#' x = c(1,4,4,4,5,12,12)
#' cpdf(x)
#'
cpdf = function( x) {
  n = length(x)
  x = sort(x)

  if (length(x) != length(unique(x))) {
    warning(
      "\n Ties have been detied..."
    )

      L = min(diff(c(0,sort(unique(x)))))

      ix.ties = sapply(x,function(e) sum(x==e)>1)
      x.ties = x[ix.ties]
      x.ties = unique(x)

      for (j in 1:length(x.ties)) {
        nn = sum(x==x.ties[j])
        ss = seq(0,by=L/10,length=nn)
        ss = ss-mean(ss)
        x[x==x.ties[j]] = x[x==x.ties[j]]+ss
      }
    }

  n.int = length(x) + 1

  p = rep(1 / (n + 1), n)
  names(p) = paste("<=",x,sep = "")
  cpdf = cumsum(p)
  names(cpdf) = paste("<=", x, sep = "")

  return(list(int=x,cpdf=cpdf))
}

