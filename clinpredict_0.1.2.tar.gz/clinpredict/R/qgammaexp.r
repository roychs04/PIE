#' Quantiles of gamma-exponential distribution
#'
#' @param p vector of probalitites for which the quantiles will be computed#'
#' @param a, b parameters of the gamma-exponential distribution
#'
qgammaexp <- function(p=c(0.025,0.5,0.975), a, b) {
  q = (1 - p) ^ (-1 / a) * b - b
  return(q)
}
