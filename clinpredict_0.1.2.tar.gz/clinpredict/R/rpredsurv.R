#' Predictive simulations for survival data using non-parametric predictive distribution by Berliner-Hill
#'
#' @param n.sim number of simulations
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators, 1 for events and 0 for censored observations. If \code{NULL},
#' no censoring is assumed
#'
#' @examples
#' data(km)
#' pred1 = rpredsurv(n.sim=1e4,time=km$time,event=km$event,
#' version="BerlinerHill")
#' pred2 = rpredsurv(n.sim=1e4,time=km$time,event=km$event)
#' sim_sum(pred1)
#' sim_sum(pred2)
#' # compare to analytic summaries
#' spredsurv(time=km$time,event=km$event)
#'

rpredsurv = function(n.sim,time,event=NULL,
                     version=c("BerlinerHill","pwgammaexp")[2]) {

  aa = cpdfsurv(time=time,event=event,version=version)

  if (version=="BerlinerHill")
    sim = rpwexp(n.sim,lambda=aa$lambda,int=aa$int)

  if (version=="pwgammaexp")
    sim = rpwgammaexp(n.sim=n.sim,a=aa$a,b=aa$b,int=aa$int)


  return(sim)
}

