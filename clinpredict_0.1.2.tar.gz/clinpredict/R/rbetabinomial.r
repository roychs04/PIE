#' Random numbers from beta-binomial distribution
#'
#' beta-binomial (overdispersed binomial)  distribution:
#' theta ~ beta(a,b), Y | theta ~ binomial(theta,n), Y ~ beta-binomilal(n,a,b)
#'
#' @param n.sim number of simulated values
#' @param n sample size
#' @param a,b parameters of beta-binomial distribution
#'
#' @examples
#'
#' print(rbetabinomial(a=1,b=1,n=4))
#' rbb = rbetabinomial(1,1,4,n.sim=1000)
#' print(table(rbb))
#'
rbetabinomial <- function(n.sim=1, n, a, b) {
  sample(
    seq(0, n),
    size = n.sim,
    replace = T,
    prob = dbetabinomial(0:n, n, a, b)
  )
}
