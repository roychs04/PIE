#' Predictive individual effect distribution for survival data
#'
#' @param data dataframe with the variables
#' \code{time} (event and censoring5 times),
#' \code{event} (event indicator, \code{1} for events, \code{0} for censoring),
#' and \code{trt} (\code{0} for control, \code{1} for test)
#' @param n.pred simulation sample size for predictive individual effect
#' distribution
#' @param intC interval boundaries for piecewise exponential control model (optional);
#' if missing, default (optimal) boundaries will be obtained using the AIC
#' criterion; if \code{NULL}, an exponential distribution will be assumed
#' @param intT interval boundaries for piecewise exponential test model
#' @param rank.method Method for predictive calculations.
#' The default is \code{"fixed"} with \code{rank.par=1}, that is, strict rank
#' rank preservation (the Lehmann-Doksum model). Alternatives
#' are \code{"beta"} or \code{"logitnormal"} (with respective parameters
#' given in \code{rank.par}), which allow for a prior distribution of the
#' rank preservation factor in the interval (0,1).
#' @param rank.par the rank-preservation fraction (if \code{fixed}) or the
#' parameters of the Beta or logit-normal distribution otherwise.
#' @param yC.cond the control times for which the conditional predictive
#' individual effect (survival gain) distribution will be obtained (optional)
#' @param trial.label trial label (only used for caption headers)
#' @param T.label the label for the test group
#' @param C.label the label for the control group
#' @param time.unit the time unit (only used for Kaplan-Meier plots)
#' @param pie.gain.cutoffs the interval with for the cumulative predictive
#' individual effect distribution
#' @param pie.cutoffs interval boundaries for the summaries of predictive
#' individual effect distribution
#' @param C.col color for control group
#' @param T.col color for test group
#' @param save.sim logical: if \code{TRUE}, simulated values for
#' control and test will be saved; default is \code{FALSE}
#'
#' @return
#' rank.pres
#' int interval boundaries for piecewise exponential analyses
#' of control and test
#' coxPH the output object from the Cox proportional hazards analysis
#' logrank  the output object from the logrank analysis
#' pwexp
#' sim
#' marg
#' pie
#' pie.gain     pie.cond
#' tables_knitr
#' figures
#'
#' @examples
#' data(leuk)
#' A = pie_surv(leuk)
#'
#'
pie_surv = function(data,
                    n.pred = 1e4,
                    intC,
                    intT,
                    rank.method = c("fixed", "beta", "logitnormal")[1],
                    rank.par = 1,
                    yC.cond = NULL,
                    cond.col = "black",
                    trial.label = "",
                    T.label = "test",
                    C.label = "control",
                    gain.label = "survival gain",
                    time.unit = "",
                    pie.gain.cutoffs = NULL,
                    pie.cutoffs = 0,
                    C.col = "red",
                    T.col = "blue",
                    save.sim = FALSE) {
  CT.label = c(C.label, T.label)


  # prepare data for Kaplan-Meier plots
  data$trt = as.factor(data$trt)
  data$group = ifelse(data$trt == 0, C.label, T.label)
  data$group = factor(data$group, levels = c(C.label, T.label))

  # Kaplan-Meier plot (pwexp fit added later)
  fig.km1 = plot_km(
    data = data,
    ci = FALSE,
    col = c(C.col, T.col),
    time.unit = time.unit
  )

  # Kaplan-Meier plot with package survminer

  fit <- survfit(Surv(time, event) ~ trt, data = data)

  # log-rank test (one sided p-value)
  test. <- survdiff(Surv(time, event) ~ trt, data = data)
  logrank <- round(1 - pnorm(sqrt(test.$chisq)), 4)

  #Cox regression
  cox <- coxph(Surv(time, event) ~ trt, data = data)
  hr <- round(exp(cox$coefficients), 2)
  hrl <- round(exp(confint(cox)[1]), 2)
  hru <- round(exp(confint(cox)[2]), 2)


  fig.km <- ggsurvplot(
    fit,
    data = data,
    pval = FALSE,
    pval.method = TRUE,
    # Add p-value &  method name
    surv.median.line = "none",
    # Add median survival lines
    legend.title = "",
    # Change legend titles
    legend.labs = c(C.label, T.label),
    # palette = "jco",
    palette = c(C.col,T.col),
    risk.table = TRUE,
    # Add No at risk table
    cumevents = FALSE,
    # Add cumulative No of events table
    tables.height = 0.15,
    # Specify tables height
    tables.theme = theme_cleantable(),
    # Clean theme for tables
    tables.y.text = FALSE,
    # Hide tables y axis text
    xlab         = time.unit,
    ylab = "survival probability",
    newpage      = FALSE
  )

  fig.km$plot <- fig.km$plot +
    ggplot2::annotate(
      "text",
      x = 0.75 * max(data$time[data$event == 1]),
      y = 0.85,
      label = paste("log-rank p-value = ", logrank, sep = "")
    ) +
    ggplot2::annotate(
      "text",
      x = 0.75 * max(data$time[data$event == 1]),
      y = 0.9,
      label = paste("hazard ratio (95% CI)=", hr, " (", hrl, ",", hru, ")", sep =
                      "")
     )

  # data for piecewise exponential analyses of control and test
  dataC = subset(data, trt == 0)
  dataT = subset(data, trt == 1)



  # default interval boundaries if missing
  if (missing(intC)) {
    yC = data$time[data$trt == 0]
    eC = data$event[data$trt == 0]
    int.cand = quantile(yC[eC == 1], seq(0.1, 0.9, by = 0.1))
    intC = pwexp_abic_search(yC, eC, int.cand = int.cand)$sel$aic$int
  }

  if (missing(intT)) {
    yT = data$time[data$trt == 1]
    eT = data$event[data$trt == 1]
    int.cand = quantile(yT[eT == 1], seq(0.1, 0.9, by = 0.1))
    intT = pwexp_abic_search(yT, eT, int.cand = int.cand)$sel$aic$int
  }

  # interval data
  if (is.null(intC))
    dataC = list(r = sum(dataC$event), E = sum(dataC$time))
  if (!is.null(intC)) {
    dataC = ipd2int(obstime = dataC$time,
                    event = dataC$event,
                    int = intC)
  }

  if (is.null(intT))
    dataT = list(r = sum(dataT$event), E = sum(dataT$time))
  if (!is.null(intT)) {
    dataT = ipd2int(obstime = dataT$time,
                    event = dataT$event,
                    int = intT)
  }

  # pwexp analyses and prediction for control
  if (!is.null(intC)) {
    AC = infer_pwexp1(dataC)
    # posterior gamma parameters by interval
    abC = AC$post.lambda[,-(1:5)]
    # simuate from posterior
    lambdaC.sim = apply(abC, 1, function(e)
      rgamma(n.pred, e[1], e[2]))
  }
  if (is.null(intC)) {
    lambdaC.sim = rgamma(n.pred, dataC$r, dataC$E)
  }


  if (!is.null(intT)) {
    # pwexp analysis and prediction for test
    AT = infer_pwexp1(dataT)
    # posterior gamma parameters by interval
    abT = AT$post.lambda[,-(1:5)]
    lambdaT.sim = apply(abT, 1, function(e)
      rgamma(n.pred, e[1], e[2]))
  }
  if (is.null(intT)) {
    lambdaT.sim = rgamma(n.pred, dataT$r, dataT$E)
  }


  # get posterior survival probabilities on fine grid
  maxT = max(data$time)

  surv.t = seq(maxT / 100, maxT, by = maxT / 100)
  if (!is.null(intC))
    survC = t(sapply(surv.t, function(e)
      sim_sum(1 - ppwexp(
        e, lambdaC.sim, intC
      ))))
  if (is.null(intC))
    survC = t(sapply(surv.t, function(e)
      sim_sum(1 - pexp(e, lambdaC.sim))))

  if (!is.null(intT))
    survT = t(sapply(surv.t, function(e)
      sim_sum(1 - ppwexp(
        e, lambdaT.sim, intT
      ))))
  if (is.null(intT))
    survT = t(sapply(surv.t, function(e)
      sim_sum(1 - pexp(e, lambdaT.sim))))

  # # data sets for pwexp plots
  ds.survC = data.frame(
    x = surv.t,
    est = survC[, 4],
    lower = survC[, 3],
    upper = survC[, 5]
  )
  ds.survT = data.frame(
    x = surv.t,
    est = survT[, 4],
    lower = survT[, 3],
    upper = survT[, 5]
  )

  fig.km.pwexp = NULL
  # # add Bayesian estimates and probability intervals to Kaplan-Meier plot
  fig.km.pwexp = fig.km1 +
    geom_line(data = ds.survC, aes(x = x, y = est), col = C.col) +
    geom_line(
      data = ds.survC,
      aes(x = x, y = lower),
      linetype = 3,
      col = C.col
    ) +
    geom_line(
      data = ds.survC,
      aes(x = x, y = upper),
      linetype = 3,
      col = C.col
    ) +
    geom_line(data = ds.survT, aes(x = x, y = est), col = T.col) +
    geom_line(
      data = ds.survT,
      aes(x = x, y = lower),
      linetype = 3,
      col = T.col
    ) +
    geom_line(
      data = ds.survT,
      aes(x = x, y = upper),
      linetype = 3,
      col = T.col
    ) +
    xlab(time.unit) +
    ylab("survival probability")
  #
  # Predictive individual effect distribution


  sum.p.sim = NULL
  sum.corr = NULL


  if (rank.method == "fixed") {
    sum.p.sim = rank.par

    if (!is.element(rank.par, c(1, 0.95, 0.9, 0.8)))
      stop("Supported values for *rank.par* are 1, 0.95, 0.9, and 0.8")

    if (is.element(rank.par, c(1, 0.95, 0.9, 0.8)))  {
      if (rank.par == 1)
        corr = 1
      if (rank.par == 0.95)
        corr = 0.9875
      if (rank.par == 0.9)
        corr = 0.951
      if (rank.par == 0.8)
        corr = 0.808

      sum.corr = corr

      zC = rnorm(n.pred, 0, 1)
      zT = rnorm(n.pred, zC * corr, sqrt(1 - corr ^ 2))
      uC = pnorm(zC)
      uT = pnorm(zT)
    }
  }

  if (rank.method == "beta") {
    p.sim = rbeta(n.pred, rank.par[1], rank.par[2])
    p.sim = 0.5 + 0.5 * p.sim
    sum.p.sim = sim_sum(p.sim)

    # get correlation-rank.preservation percentage data
    x = dget("rankpreserve.dmp")

    sim = t(sapply(1:length(p.sim), function(e) {
      ix = which.min(abs(x$p.rankpreserve - p.sim[e]))
      out = x[ix, ]
      return(out)
    }))
    corr = unlist(sim[, 1])
    sum.corr = sim_sum(corr)

    zC = rnorm(n.pred, 0, 1)
    zT = rnorm(n.pred, zC * corr, sqrt(1 - corr ^ 2))

    uC = pnorm(zC)
    uT = pnorm(zT)
  }

  if (rank.method == "logitnormal") {
    p.sim = expit(rnorm(n.pred, rank.par[1], rank.par[2]))
    p.sim = 0.5 + 0.5 * p.sim
    sum.p.sim = sim_sum(p.sim)

    # get correlation-rank.preservation percentage data
    x = dget("rankpreserve.dmp")

    sim = t(sapply(1:length(p.sim), function(e) {
      ix = which.min(abs(x$p.rankpreserve - p.sim[e]))
      out = x[ix, ]
      return(out)
    }))
    corr = unlist(sim[, 1])
    sum.corr = sim_sum(corr)

    zC = rnorm(n.pred, 0, 1)
    zT = rnorm(n.pred, zC * corr, sqrt(1 - corr ^ 2))

    uC = pnorm(zC)
    uT = pnorm(zT)
  }

  # percentage of cases fulfilling rank preservation
  rank.pres.frac = mean((zC > 0 & zT > 0) | (zC <= 0 & zT <= 0))

  # now simulate predictive control and test times

    if (!is.null(intC))
      yC.pred = sapply(1:length(uC), function(e)
        qpwexp(uC[e], lambda = lambdaC.sim[e, ], int = intC))
    if (is.null(intC))
      yC.pred = qexp(uC, lambdaC.sim)

  if (!is.null(intT))
    yT.pred = sapply(1:length(uT), function(e)
      qpwexp(uT[e], lambda = lambdaT.sim[e, ], int = intT))
  if (is.null(intT))
    yT.pred = qexp(uT, lambdaT.sim)

  marg.sum = rbind(sim_sum(yC.pred),
                   sim_sum(yT.pred))
  row.names(marg.sum) = CT.label


  pie = yT.pred - yC.pred
  pie.sum = sim_sum(pie,cutoffs=pie.cutoffs)
  rownames(pie.sum) = NULL


  # conditional distribution for assumed yC values
  pie.cond = NULL
  if (!is.null(yC.cond))   {

    for (j in 1:length(yC.cond)) {
      y = yC.cond[j]

      if (!is.null(intC)) {
        pC = sapply(1:n.pred, function(e)
          ppwexp(y, lambdaC.sim[e,], int = intC)
        )
      }
      if (is.null(intC)) {
        pC = pexp(y, lambdaC.sim)
      }

      if (!is.null(intT))
      yT.C = sapply(1:n.pred, function(e)
        qpwexp(pC[e], lambdaT.sim[e,], int = intT))
      if (is.null(intT))
        yT.C = qexp(pC, lambdaT.sim)

      pie.cond = rbind(pie.cond, sim_sum(yT.C - y,cutoffs=pie.cutoffs))
    }
    rownames(pie.cond) = paste(C.label,"=", yC.cond, sep = "")
  }

  # knitr tables: for marginal distributions, predictive individual
  # effect distribution, and conditional effect distribution
  tab.marg = knitr::kable(
    marg.sum,
    row.names = TRUE,
    caption =
      paste(
        trial.label,
        ": predictive ",
        C.label,
        " and ",
        T.label,
        " survival times",
        sep = ""
      )
  )

  tab.pie = knitr::kable(
    pie.sum,
    caption =
      paste(trial.label, ": predictive individual effect (T-C)"),
    row.names = FALSE
  )



  tab.pie.cond = NULL
  fig.cond = NULL
  if (!is.null(pie.cond)) {

  tab.pie.cond = knitr::kable(
    pie.cond,
    row.names = TRUE,
    caption = paste(
      trial.label,
      ": conditional predictive survival gain (",
      T.label,
      "--",
      C.label,
      ")",
      sep = ""
    )
  )


  est  <- pie.cond[,4]
  low <- pie.cond[,3]
  up <- pie.cond[,5]

  fig.cond = plot_estlowup(x=yC.cond,
               est = est,
               low = low,
               up = up,
               ylab=gain.label,
               xlab="control time",
               col.pos = T.col,
               col.neg = C.col
  )

  fig.cond = fig.cond + theme_classic()

  fig.cond = fig.cond +
    theme(axis.title.x = element_text(size=rel(1.1))) +
    theme(axis.title.y = element_text(size=rel(1.1)))


  }


  # default values
  if (is.null(pie.gain.cutoffs)) {

    r.pie = diff(quantile(pie, c(0.1, 0.9)))
    if (r.pie < 5)
      bin = 0.5
    if (r.pie >= 5 & r.pie < 100)
      bin = floor(r.pie / 10) + 1
    if (r.pie >= 5 & r.pie > 100)
      bin = (floor(r.pie / 100) + 1) * 10

    seq.pos = seq(0,floor(max(abs(pie))/bin),by=bin)
    seq.neg = sort(-seq.pos[-1])
    seq.all = c(seq.neg,seq.pos)

    seq.all = seq.all[seq.all>quantile(pie,0.05) &
                        seq.all<quantile(pie,0.95)]
    if (0<min(seq.all))
      seq.all = seq(0,max(seq.all),by=bin)
    if (0>max(seq.all))
      seq.all = seq(min(seq.all),0,by=bin)
    pie.gain.cutoffs = seq.all
    }

  pie.gain.sum = pie_gain(pie,cutoffs=pie.gain.cutoffs)

  tab.pie.gain = knitr::kable(
    pie.gain.sum,
    caption =
      paste(
        trial.label,
        ": cumulative predictive individual effect distribution",
        sep = ""
      )
  )

  negpos = pie.gain.cutoffs>=0
  if (min(pie.gain.cutoffs)>0)
    negpos = c("TRUE",negpos)
  else
    negpos = c("FALSE",negpos)

  y = pie.gain.sum
  x = names(pie.gain.sum)
  x = factor(x,levels=x)
  fig.gain = plot_bar(y=y,group=x,
                      subgroup=negpos,
                      col.subgroup=c(C.col, T.col),
                      xlab=gain.label,
                      ylab="probability",
                      show.legend=FALSE,
                      ylim=c(0,1))

  sel = pie.gain.sum>0.005
  fig.gain = fig.gain  +
    ggplot2::annotate(
      "text",
      x = names(pie.gain.sum[sel]),
      y = unlist(pie.gain.sum)[sel] + 0.03,
      label = round(unlist(pie.gain.sum)[sel], 2),
      size=3.5
    )

  if (!save.sim)
    sim.out =   "simulated values not saved: set *save.sim=TRUE*"
  if (save.sim) {
    sim.out = data.frame(control = yC.pred, test = yT.pred)
    row.names(sim.out) = NULL
  }

  if (!is.null(intC))
    control = AC
  if (is.null(intC))
    control = sim_sum(lambdaC.sim)

  if (!is.null(intT))
    test = AT
  if (is.null(intT))
    test=sim_sum(lambdaT.sim)


  return(
    list(
      rank.pres = list(fraction = sum.p.sim,
                       gauss.copula.corr = sum.corr),
      int = list(intC = intC, intT = intT),
      coxPH = cox,
      logrank = logrank,
      pwexp = list(control=control,test=test),
      sim = sim.out,
      marg = marg.sum,
      pie = pie.sum,
      pie.gain = pie.gain.sum,
      pie.cond = pie.cond,
      tables_knitr = list(
        marg = tab.marg,
        pie = tab.pie,
        pie.cond = tab.pie.cond,
        pie.gain = tab.pie.gain
      ),
      figures = list(
        km = fig.km,
        km.pwexp = fig.km.pwexp,
        # pie.sample = fig.pie.sample,
        pie.gain = fig.gain,
        pie.cond = fig.cond
      )
    )
  )
}

