#' Predictive inference for piecewise exponential models with covariates
#'
#' @param time n-vector of observation and censoring times
#' @param event n-vector of event indicators: 1 for event, 0 for censoring
#' @param X nxk matrix of covariates; \code{int=NULL} assumes no covariates
#' @param int interval boundaries; \code{int=NULL} assumes an exponential model
#' @param Xout n.outxk matrix of covariates for which predictions will be obtained; see \emph{Details} for unspecified \code{Xout}
#' @param prior.beta a \code{kx2} matrix with mean (1st column) and standard deviation (2nd column) of normal priors for the \code{k} regression coefficients. Alternatively, a 2-vector with mean and standard deviation can be specified. In this case, the same prior distribution is used for all regression parameters.
#' @param prior.beta.cor 
#' @param prior.loglambda ...
#' @param prior.loglambda.cor ...
#' @param probs vector of probabilities for which quantiles will be obtained
#' @param mcmc 4-vector of MCMC parameters for \emph{JAGS} or \emph{WinBUGS}, i.e., \code{(n.burnin,n.iter,n.chains,n.thin)}
#' @param Rhat.crit: critical value for Gelman-Rubin diagnostic; if exceeded, a warning will be issued
#' @param engine MCMC software: \code{"jags"} or \code{"winbugs"}
#' @param jags.progress.bar controls output to screen while \emph{JAGS} is running (\code{"none"} or \code{"text"})
#' @param debug stops \emph{WinBUGS} at the end of the MCMC run
#' @param bugs.dir home directory of \emph{WinBUGS} software
#'
#' @return specs model specifications: interval boundaries and priors for beta and lambda parameters
#' @return jagswb: \emph{JAGS} or \emph{WinBUGS} output object
#' @return sim list of simulated parameters specified in \code{pars}
#' @return sim list of summaries for parameters specified in \code{pars}
#' @return Rhat: Gelman Rubin Rhat diagnostics if at least one of them exceeds 1.1
#' @return DIC: deviance information criterion and effective number of parameters
#'
#' @examples
#'
#' data(leuk)
#' time = leuk$time
#' event = leuk$event
#' X = leuk$trt
#' ex = pred_survcov2(time=time,event=event,
#'                   X = X, Xout = cbind(c(0,1)),
#'                   int=5)
#' names(ex)
#' ex$sum$pred
#' ex$sum$beta
#'
pred_survcov = function(time,
                         event,
                         X = NULL,
                         int = NULL,
                         Xout = NULL,
                         prior.beta = NULL,
                         prior.beta.cor = 0.5,
                         prior.loglambda = NULL,
                         prior.loglambda.cor = 0.5,
                         pars = c("pred", "beta", "lambda", "lambdaX"),
                         probs = c(0.025, 0.5, 0.975),
                         cutoffs = 0,
                         mcmc = c(1000, 11000, 4, 1),
                         Rhat.crit = 1.1,
                         DIC = TRUE,
                         engine = c("jags", "winbugs")[1],
                         jags.progress.bar = c("none", "text")[2],
                         debug = FALSE,
                         bugs.dir = "C:/WinBUGS14")
{
  specs = list()
  if (is.null(int))
    specs$int = "exponential model"
  else
    specs$int = int
  
  
  if (!is.null(int)) {
    int0 = c(0, int)
    int.len = cbind(diff(int0))
    
    # data format for WB/jags
    # breaks data up into interval format
    wb_data = function(time, event, x, int) {
      k = length(int) + 1
      n = length(time)
      
      IB = c(0, int)
      # interval length
      L = diff(IB)
      
      nj = sapply(1:n, function(e)
        sum(time[e] > IB))
      
      if (!is.null(x))
        x = cbind(x)
      x1 = NULL
      sub = NULL
      int1 = NULL
      E1 = NULL
      status1 = NULL
      
      for (j in 1:n) {
        for (jj in 1:nj[j]) {
          sub = c(sub, j)
          int1 = c(int1, jj)
          if (!is.null(x))
            x1 = rbind(x1, x[j, ])
          E1 = c(E1, ifelse(jj < nj[j], L[jj], time[j] - IB[jj]))
          status1 = c(status1, ifelse(jj < nj[j], 0, event[j]))
        }
      }
      if (!is.null(x))
        wb = data.frame(
          sub = sub,
          int = int1,
          E = E1,
          event = status1,
          x = x1
        )
      else
        wb = data.frame(
          sub = sub,
          int = int1,
          E = E1,
          event = status1
        )
      
      return(list(
        wb = wb,
        subject = sub,
        int = int1,
        E = E1,
        event = status1,
        x = x1
      ))
    }
    
    ds = wb_data(
      time = time,
      event = event,
      x = X,
      int = int
    )
    
    # data for wb/jags model
    int = ds$int
    X = ds$x
    E = ds$E
    event = ds$event
    
    n.obs = length(E)
    n.int = max(int)
    
    
    no.cov = ifelse(is.null(X), TRUE, FALSE)
    if (no.cov) {
      X = cbind(rep(0, n.obs))
      pars = pars[pars != "beta"]
    }
    
    X = cbind(X)
    n.cov = ncol(X)
    
    if (is.null(Xout))
      Xout = matrix(0, 1, ncol(X))
    
    # priors for interval hazards and regression coefficient
    #
    #     # crude hazard estimate (for centering weakly-informative lambda priors)
    haz.est = sum(event) / sum(E)
    
    
    if (is.null(prior.beta))
      prior.beta = c(0, 2)
    if (length(prior.beta) == 2)
      prior.beta = matrix(prior.beta, n.cov, 2, byrow = TRUE)
    
    colnames(prior.beta) = c("normal.mean", "normal.sd")
    rownames(prior.beta) = paste("cov", 1:n.cov, sep = "")
    
    prior.beta.mn = matrix(prior.beta[, 1], n.int, n.cov, byrow = TRUE)
    
    rho = prior.beta.cor ^ (1 / (n.int - 1))
    rrmm = matrix(1:n.int, nrow = n.int, ncol = n.int)
    rrmm = abs(rrmm - t(rrmm))
    prior.beta.cor = rho ^ rrmm
    
    prior.beta.cov = prior.beta.prec = array(NA, c(n.int, n.int,n.cov))
    for (j in 1:n.cov) {
      sd = matrix(rep(prior.beta[j, 2], n.int), ncol = 1)
      pb.cov =  sd %*%  t(sd) * prior.beta.cor
      prior.beta.cov[1:n.int, 1:n.int,j] = pb.cov
      prior.beta.prec[1:n.int, 1:n.int,j] = solve(pb.cov)
    }
    
    
    if (is.null(prior.loglambda))
      prior.loglambda = cbind(rep(log(haz.est), n.int), rep(1, n.int))
    
    colnames(prior.loglambda) = c("normal.mean", "normal.sd")
    
    rho = prior.loglambda.cor ^ (1 / (n.int - 1))
    rrmm = matrix(1:n.int, nrow = n.int, ncol = n.int)
    rrmm = abs(rrmm - t(rrmm))
    prior.loglambda.cor = rho ^ rrmm
    prior.loglambda.cov = matrix(prior.loglambda[, 2], ncol = 1) %*%
      matrix(prior.loglambda[, 2], nrow = 1) * prior.loglambda.cor
    prior.loglambda.prec = solve(prior.loglambda.cov)
    
    Xout = cbind(Xout)
    if (ncol(Xout) != n.cov)
      stop("Xout must be a matrix: the number of columns must match the number of covariates")
    
    n.xout = nrow(Xout)
    
    xout.nms = rownames(Xout)
    if (is.null(xout.nms))
      xout.nms = apply(Xout, 1, function(e)
        paste(e, collapse = "/"))
    
    #wb/jags input
    data.in <-
      list(
        "n.obs",
        "n.int",
        "n.cov",
        "n.xout",
        "int",
        "int.len",
        "E",
        "event",
        "X",
        "Xout",
        "prior.beta.mn",
        "prior.beta.prec",
        "prior.loglambda",
        "prior.loglambda.prec"
      )
    
    inits = function()
      list(loglambda = prior.loglambda[, 1],
           beta = matrix(0,n.cov,n.int))
    
    model <- function() {
      for (k in 1:n.cov) {
        #beta[1:n.int, k] ~ dmnorm(prior.beta.mn[1:n.int, k], prior.beta.prec[1:n.int, 1:n.int,k])
        beta[k,1:n.int] ~ dmnorm(prior.beta.mn[1:n.int, k], prior.beta.prec[1:n.int, 1:n.int,k])
      }
      
      loglambda[1:n.int] ~ dmnorm(prior.loglambda[1:n.int, 1],
                                  prior.loglambda.prec[1:n.int, 1:n.int])
      for (j in 1:n.int) {
        lambda[j, 1] <- exp(loglambda[j])
      }
      
      # likelihood for event/censor' intervals
      for (i in 1:n.obs) {
        poismean[i] <-
          lambda[int[i], 1] * exp(inprod(beta[1:n.cov,int[i]], X[i, 1:n.cov])) *
          E[i]
        event[i] ~ dpois(poismean[i])
      }
      
      # PREDICTIONS: LOOP OVER OUTPUT COVARIATE PATTERNS
      for (k in 1:n.xout) {
        # FIRST INTERVAL
        lambdaX[1, k] <-
          lambda[1, 1] * exp(inprod(beta[1:n.cov,1], Xout[k, 1:n.cov]))
        y1[1, k] ~ dexp(lambdaX[1, k])
        no.int[1, k] <- step(y1[1, k] - int.len[1, 1])
        in.int[1, k] <- 1 - no.int[1, k]
        ind[1, k]  <- in.int[1, k]
        y2[1, k] <- no.int[1, k] * int.len[1, 1] + in.int[1, k] * y1[1, k]
        
        # Y1 always contributes
        sel[1, k] <- 1
        
        # SUBSEQUENT INTERVALS
        for (j in 2:(n.int - 1)) {
          lambdaX[j, k] <-
            lambda[j, 1] * exp(inprod(beta[1:n.cov,j], Xout[k, 1:n.cov]))
          y1[j, k] ~ dexp(lambdaX[j, k])
          # indicator for event not in interval j
          no.int[j, k] <- step(y1[j, k] - int.len[j, 1])
          in.int[j, k] <- 1 - no.int[j, k]
          y2[j, k] <- no.int[j, k] * int.len[j, 1] + in.int[j, k] * y1[j, k]
          
          # event before interval j? Select Y of interval j only if not!
          ind[j, k] <- sum(ind[1:(j - 1), k])
          sel[j, k] <- 1 - step(ind[j, k] - 0.5)
        }
        
        # LAST INTERVAL
        lambdaX[n.int, k] <-
          lambda[n.int, 1] * exp(inprod(beta[1:n.cov,n.int], Xout[k, 1:n.cov]))
        y2[n.int, k] ~ dexp(lambdaX[n.int, k])
        ind[n.int, k] <- sum(ind[1:(n.int - 1), k])
        sel[n.int, k] <- 1 - step(ind[n.int, k] - 0.5)
        
        # Prediction: sum over piecewise exponentials for
        pred[k] <- inprod(sel[1:n.int, k], y2[1:n.int, k])
      }
    }
  }  # end of piecewise-exponential case
  
  
  if (is.null(int)) {
    n.obs = length(time)
    
    no.cov = ifelse(is.null(X), TRUE, FALSE)
    if (no.cov) {
      X = cbind(rep(0, n.obs))
      pars = pars[pars != "beta"]
    }
    
    X = cbind(X)
    n.cov = ncol(X)
    
    if (is.null(Xout))
      Xout = matrix(0, 1, ncol(X))
    
    # priors for interval hazards and regression coefficient
    
    if (is.null(prior.beta))
      prior.beta = c(0, 2)
    if (length(prior.beta) == 2)
      prior.beta = matrix(prior.beta, n.cov, 2, byrow = TRUE)
    
    colnames(prior.beta) = c("normal.mean", "normal.sd")
    rownames(prior.beta) = paste("cov", 1:n.cov, sep = "")
    
    # crude hazard estimate (for centering weakly-informative lambda priors)
    haz.est = sum(event) / sum(time)
    
    if (is.null(prior.loglambda))
      prior.loglambda = c(log(haz.est), 1)
    
    Xout = cbind(Xout)
    if (ncol(Xout) != n.cov)
      stop("Xout must be a matrix: the number of columns must match the number of covariates")
    
    n.xout = nrow(Xout)
    
    xout.nms = rownames(Xout)
    if (is.null(xout.nms))
      xout.nms = apply(Xout, 1, function(e)
        paste(e, collapse = "/"))
    
    #wb/jags input
    data.in <-
      list(
        "n.obs",
        "n.cov",
        "n.xout",
        "time",
        "event",
        "X",
        "Xout",
        "prior.beta",
        "prior.loglambda"
      )
    
      inits = function()
        list(loglambda = prior.loglambda[1])
      
    
    
    model <- function() {
      for (k in 1:n.cov) {
        beta0[k, 1] ~ dnorm(0, 1)
        beta[k, 1] <- prior.beta[k, 1] + prior.beta[k, 2] * beta0[k, 1]
      }
      
      # lambda prior
      loglambda ~ dnorm(prior.loglambda[1], prior.loglambda[2])
      lambda <- exp(loglambda)
      
      # likelihood for event/censor' intervals
      for (i in 1:n.obs) {
        poismean[i] <-
          lambda * exp(inprod(beta[1:n.cov, 1], X[i, 1:n.cov])) * time[i]
        event[i] ~ dpois(poismean[i])
      }
      
      
      # PREDICTIONS: LOOP OVER OUTPUT COVARIATE PATTERNS
      for (k in 1:n.xout) {
        lambdaX[k] <-
          lambda * exp(inprod(beta[1:n.cov, 1], Xout[k, 1:n.cov]))
        pred[k] ~ dexp(lambdaX[k])
      }
    }
    
  } # end of exponential case
  
  
  if (engine == "jags") {
    fit <-
      jags(
        data = data.in,
        parameters.to.save = pars,
        model.file = model,
        n.iter = mcmc[2],
        n.chains = mcmc[3],
        n.burnin = mcmc[1],
        n.thin = mcmc[4],
        progress.bar = jags.progress.bar
      )
  }
  
  if (engine == "winbugs") {
    fit <-
      bugs(
        data = data.in,
        inits = inits,
        parameters.to.save = pars,
        model.file = model,
        n.burnin = mcmc[1],
        n.iter = mcmc[2],
        n.chains = mcmc[3],
        n.thin = mcmc[4],
        debug = debug,
        bugs.dir = bugs.dir
      )
  }
  
  if (engine == "jags") {
    fitsum = fit$BUGSoutput$summary
    sims.matrix = fit$BUGSoutput$sims.matrix
    fit$sims.list = NULL
    fit$sims.array = NULL
    fit$sims.matrix = NULL
  }
  if (engine == "winbugs") {
    fitsum = fit$summary
    sims.matrix = fit$sims.matrix
    fit$sims.list = NULL
    fit$sims.array = NULL
    fit$sims.matrix = NULL
  }
  
  out.sum = sum_jagswb(pars, fitsum)
  out.sum$jagswb = fitsum
  out.sim = sim_jagswb(pars, sims.matrix)
  
  Rhat = fitsum[, "Rhat"]
  if (any(Rhat > Rhat.crit)) {
    warning("Note: there are Rhat diagnostic values > ",
            Rhat.crit)
    print(Rhat[Rhat > Rhat.crit])
  }
  
  if (DIC & engine == "winbugs") {
    out.DIC = list(DIC = fit$DIC, pD = fit$pD)
  }
  if (DIC & engine == "jags") {
    out.DIC = list(DIC = fit$BUGSoutput$DIC,
                   pD = fit$BUGSoutput$pD)
  }
  
  if (no.cov)
    prior.beta = "no covariates"
  
  if (!no.cov) {
    if (!is.null(int))
      prior.beta = list(mn.sd = prior.beta, cor = prior.beta.cor)
    else
      prior.beta = prior.beta
  }
  
  specs$prior.beta = prior.beta
  
  if (!is.null(int))
    specs$prior.loglambda = list(mn.sd = prior.loglambda, cor = prior.loglambda.cor)
  else
    specs$prior.loglambda = c(normal.mn = prior.loglambda[1],
                              normal.sd = prior.loglambda[2])
  
  # clarify indices for beta and lambdaX
  # Note: JAGS and WinBUGS have different ordering of indices!
  
  if (is.element("beta", pars) & !no.cov) {
    out.sum$beta = rbind(out.sum$beta)
    rn = rownames(out.sum$beta)
    rn = gsub("\\[", "[cov", rn)
    rn = gsub(",", ",int", rn)
    rownames(out.sum$beta) = rn
    
    out.sim$beta = cbind(out.sim$beta[[1]])
    rn = colnames(out.sim$beta)
    rn = gsub("\\[", "[cov", rn)
    rn = gsub(",", ",int", rn)
    colnames(out.sim$beta) = rn
  }
  
    if (is.element("lambdaX", pars) & !is.null(int)) {
      rn = rownames(out.sum$lambdaX)
      rn = gsub("\\[", "[int", rn)
      rn = gsub(",", ",xout", rn)
      rownames(out.sum$lambdaX) = rn
      
      out.sim$lambdaX = out.sim$lambdaX[[1]]
      rn = colnames(out.sim$lambdaX)
      rn = gsub("\\[", "[int", rn)
      rn = gsub(",", ",xout", rn)
      colnames(out.sim$lambdaX) = rn
    }

  return(list(
    specs = specs,
    jagswb = fit,
    sim = out.sim,
    sum = out.sum,
    Rhat = list(Rhat = Rhat, Rhat.max = max(Rhat)),
    DIC = out.DIC
  ))
}

