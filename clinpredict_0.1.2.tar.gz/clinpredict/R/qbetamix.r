#' Quantiles of mixture of beta distributions
#'
#' @param p vector of probalitites
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distributionwab
#' @param eps
#'
#' @examples
#' wab = list(c(0.2,6,2), c(0.8,25,3))
#' p = 0.75
#' q = qbetamix( p, wab)
#' print(q)
#' # check
#' print( pbetamix(q,wab))
#' curve( pbetamix(x,wab),type="l",lwd=2)
#' abline(h=p,lty=3)
#' abline(v=q,lty=3)
#'
qbetamix = function(p = c(0.025, 0.5, 0.975),
                    wab,
                    eps = 1e-5) {
  q = 0 + p
  for (j in 1:length(p)) {
    x.grid = seq(eps, 1 - eps, by = eps)
    ppp = pbetamix(x.grid, wab)
    iii = which.min(abs(ppp - p[j]))
    q[j] = x.grid[iii]
    names(q) = p
  }
  return(q)
}
