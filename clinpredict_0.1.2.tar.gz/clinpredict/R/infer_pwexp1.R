#' @title Bayesian inference for one-group piecewise exponential data
#'
#' @param dat data set with interval data: number of events \code{(nevents)}, exposure time \code{(exptime)}, and interval boundaries \code{(intlow,inthigh)}
#' @param prior.lambda a 2-vector or \code{n.intx2} matrix with parameters \code{a} and \code{b}  of Gamma(a,b) prior distributions for the interval hazards;
#' if \code{NULL}, a default prior corresponding to one event (in total over all intervals) is selected; that is, the first parameter is \code{a=1/n.int}. The other parameter \code{b} will be chosen such that the prior mean hazard \code{a/b} equals the estimated pooled hazard over all intervals
#' @param prob a scalar, the probability that defines the quantile of interest; default is \code{0.5} (the median)
#' @param cutoffs cutoffs defining intervals
#' @param n.sim number of simulations used to obtain posterior distributions for the quantile and
#' the survival probabilities
#'
#' @return prior.lambda: prior summaries for hazards
#' @return post.lambda: prior summaries for hazards
#' @return prior.surv:  prior summaries for survival at interval boundaries
#' @return post.surv: posterior summaries for survival at interval boundaries
#' @return prob.qntl: the probability that defines the quantile \code{(=prob)}
#' @return post.qntl: posterior summaries for the quantile, including cutoff probabilities
#'
#' @details
#' A conjugate Bayesian analysis (exponential sampling distribution,
#' Gamma prior distributions) is performed for each interval.
#' Posterior summaries for survival probabilities and quantiles are then obtained by simulation.
#'
#' @examples
#'
#' data(aura3)
#' A1 = infer_pwexp1(aura3,cutoffs=4:6)
#' # median
#' A1$post.qntl
#'
#' data(impress)
#' A2 = infer_pwexp1(impress)
#' A2$post.qntl
#'
infer_pwexp1 = function(
                        dat,
                        prior.lambda = NULL,
                        prob=0.5,
                        cutoffs = NULL,
                        n.sim = 1e5)
{

  if (length(prob)>1)
    stop("*prob* must be a scalar")

  check_intdata(dat)

  int0 = sort(unique(dat$intlow))
  n.int = length(int0)
  int = int0[-1]

  haz.est = sum(dat$nevents) / sum(dat$exptime)

  if (is.null(prior.lambda))
    prior.lambda = matrix(rep(c(1/n.int,1/n.int/haz.est), each = n.int), n.int, 2)

  if (length(prior.lambda) == 2)
    prior.lambda = matrix(rep(prior.lambda, each = n.int), n.int, 2)

  post.lambda = prior.lambda + 0
  for (j in 1:n.int) {
    post.lambda[j,] = prior.lambda[j,] + c(dat$nevents[j], dat$exptime[j])
  }
  post.sim = sapply(1:n.int, function(e) {
  rlam = rgamma(n.sim, post.lambda[e,1], post.lambda[e,2])
  return(rlam)
  }
  )

  qqq = qpwexp(p=prob,post.sim,dat$inthigh[-n.int])
  qntl.post = sim_sum(qqq,cutoffs=cutoffs)


  colnames(prior.lambda) = c("gamma.a", "gamma.b")
  colnames(post.lambda) = c("gamma.a", "gamma.b")

  prior.lambda = cbind(sgamma(prior.lambda[,1],prior.lambda[,2]),prior.lambda)
  post.lambda = cbind(sgamma(post.lambda[,1],post.lambda[,2]),post.lambda)

  L = dat$inthigh - dat$intlow

  surv.post = NULL
  survcum = rep(1,n.sim)

  for (j in 1:(n.int-1)) {
  survcum = survcum * exp( -rgamma(n.sim,post.lambda[j,"gamma.a"],post.lambda[j,"gamma.b"])*L[j])
  surv.post = rbind(surv.post,sim_sum(survcum))
}
  surv.post = cbind(surv.post,int)

  surv.prior = NULL
  survcum = rep(1,n.sim)

  for (j in 1:(n.int-1)) {
  survcum = survcum * exp( -rgamma(n.sim,prior.lambda[j,"gamma.a"],prior.lambda[j,"gamma.b"])*L[j])
  surv.prior = rbind(surv.prior,sim_sum(survcum))
}
  surv.prior = cbind(surv.prior,int)

  rownames(surv.prior) = rownames(surv.prior) = paste(">",int,sep="")
  rownames(surv.post) = rownames(surv.post) = paste(">",int,sep="")

  return(
    list(
      prior.lambda = prior.lambda,
      post.lambda = post.lambda,
      prior.surv = surv.prior,
      post.surv = surv.post,
      prob.qntl = prob,
      post.qntl = qntl.post
    )
  )
}


