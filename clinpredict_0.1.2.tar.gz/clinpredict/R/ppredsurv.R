#' Cumulative predictive distribution function using non-parametric Berliner-Hill predictive distribution
#'
#' @param q vector of quantiles
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators, 1 for events and 0 for censored observations. If \code{NULL},
#' no censoring is assumed
#' @param original version ("BerlinerHill") or modified version ("pwgammaexp")#'
#'
#' @examples
#' data(km)
#' ppredsurv(q=seq(2,12,by=2),time=km$time,event=km$event)
#' ppredsurv(q=seq(2,12,by=2),time=km$time,event=km$event,
#' version="BerlinerHill")
#'
ppredsurv = function(q,time,event=NULL,version=c("BerlinerHill","pwgammaexp")[2]) {

  # for rightcensored data
  if (is.null(event))
    event = rep(1,length(time))

  if (version=="BerlinerHill") {
    a = cpdfsurv(time,event,version="BerlinerHill")
    cpdf = a$cpdf
    lambda = a$lambda
    int = a$int

    p.pred = ppwexp(q,lambda=lambda,int=int)
    p.pred = as.vector(p.pred)
    names(p.pred) = q
  }
  if (version=="pwgammaexp") {
    aa = cpdfsurv(time,event,version="pwgammaexp")
    cpdf = aa$cpdf
    a = aa$a
    b = aa$b
    int = aa$int
    p.pred = ppwgammaexp(q,a,b,int=int)
    p.pred = as.vector(p.pred)
    names(p.pred) = q
  }

  return(p.pred)
}


