#' Extraction of summaries from JAGS/WinBUGS analysis
#'
#' @param pars vector of parameter names for which simulated values wil be extracted
#' @param out summary matrix from JAGS/WinBUGS output object
#' @param matrix2list logical, defaults to \code{TRUE} for output as a list
#'
sum_jagswb <-  function(pars,
                        out,
                        matrix2list = FALSE,
                        sum.cols =  c("mean", "sd", "2.5%", "50%", "97.5%")) {
  allout = list()

  for (j in 1:length(pars)) {
    parsj = pars[j]
    out = rbind(out)
    vnames <- rownames(out)
    out.ix = ix_sel(parsj, vnames, matrix2list = matrix2list)
    if (is.list(out.ix))
      out.simsum = lapply(out.ix, function(e)
        out[e, sum.cols])
    else
      out.simsum = rbind(out)[out.ix, sum.cols]

    allout[[j]] = out.simsum

  }
  names(allout) = pars

  allout = lapply(allout, function(e) {
    if (is.list(e) & length(e) == 1)
      return(e[[1]])
    else
      return(e)
  })

  return(allout)
}
