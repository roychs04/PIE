#' Summaries of exponential distribution
#'
#' @param haz parameter (hazard=1/mean) of exponential distribution
#' @param probs vector of probabilities for which quantiles will be giv@en
#' @param cutoffs cutoff values defining intervals
#'
sexp <-
  function(haz,
           probs = c(0.025, 0.5, 0.975),
           cutoffs = NULL
) {
    out = sgamma(1,haz,probs=probs,cutoffs=cutoffs)
    return(out)
  }
