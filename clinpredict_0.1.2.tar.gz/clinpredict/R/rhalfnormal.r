#' Random numbers from half-normal distribution
#'
#' @param n.sim number of simulations
#' @param scale parameter
#'
rhalfnorm = function(n.sim=1,scale=1) {
  scale*abs(rnorm(n.sim))
}

