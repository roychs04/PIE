#' Summaries of non-parametric predictive distribution by Hill
#'
#' @param x data vector
#' @param low lower bound for data
#' @param up upper bound for data
#' @param probs probabilities for which quantiles will be obtained; default is median and 95%-interval
#'
#' @examples
#' x = c(1,4,5,12)
#' spred(x)
#'
spred = function(x,low=-Inf,up=+Inf,probs=c(0.025,0.5,0.975)) {

  x = sort(x)

  # Mean and variance functions for truncated normal; needed for unbounded observations
  mean.tnorm = function(mu=0,sigma=1,a=0,b=+Inf) {
    if (b<=a | mu>b | mu<a )
      stop("mu must be in (a,b), a<b")
    a = (a-mu)/sigma
    b = (b-mu)/sigma
    mn = mu-sigma*(dnorm(b)-dnorm(a))/(pnorm(b)-pnorm(a))
    return(mn)
  }

  var.tnorm = function(mu=0,sigma=1,a=0,b=+Inf) {
    if (b<=a | mu>b | mu<a )
      stop("mu must be in (a,b), a<b")
    a = (a-mu)/sigma
    b = (b-mu)/sigma
    if (a>-Inf & b<+Inf)
      vr = sigma^2*(1-(b*dnorm(b)-a*dnorm(a))/(pnorm(b)-pnorm(a))-
                      (dnorm(b)-dnorm(a))^2/(pnorm(b)-pnorm(a))^2)

    if (a>-Inf & b==Inf)
      vr = sigma^2*(1+a*dnorm(a)/(1-pnorm(a))-dnorm(a)^2/(1-pnorm(a))^2)

    if (a==-Inf & b<+Inf)
      vr = sigma^2*(1-b*dnorm(b)/pnorm(b)-dnorm(b)^2/pnorm(b)^2)

    if (a==-Inf & b==+Inf)
      vr = sigma^2

    return(vr)
  }



  if (low == -Inf & up == +Inf) {

    cp = cpdf(x)
    cpdf = cp$cpdf
    x = cp$int

    ms = get_ms(min(x),max(x),probs=range(cpdf))

    mn = ms[1]
    sd = ms[2]

    int.length=diff(x)
    mn.int = x[1:(length(x)-1)] + int.length/2
    vr.int = int.length^2/12
    p.int = diff(c(0,cpdf,1))

    # last and first interval (for unbounded case)

    # last interval
    mn1 = mean.tnorm(a=-Inf,b=max(x),mn,sd)
    vr1 = var.tnorm(a=-Inf,b=max(x),mn,sd)

    p1 = max(cpdf)
    mn2 = (mn-mn1*p1)/(1-p1)
    vr2 = (sd^2-p1*vr1-p1*(mn1-mn)^2-(1-p1)*(mn2-mn)^2)/(1-p1)

    # checks:
    # sim = rnorm(5e6,mn,sd)
    # sim = sim[sim>max(x)]
    # last interval
    # c(mean(sim),var(sim))
    # c(mn2,vr2)

    mn.int = c(mn.int,mn2)
    vr.int = c(vr.int,vr2)

    # fist interval
    mn2 = mean.tnorm(a=min(x),b=+Inf,mn,sd)
    vr2 = var.tnorm(a=min(x),b=+Inf,mn,sd)

    p2 = min(cpdf)

    mn1 = (mn-mn2*(1-p2))/p2
    vr1 = (sd^2-(1-p2)*vr2-(1-p2)*(mn2-mn)^2-p2*(mn1-mn)^2)/p2

    mn.int = c(mn1,mn.int)
    vr.int = c(vr1,vr.int)

    # use mixture formulas for mean and variance
    mn.all = sum(p.int*mn.int)
    vr.all = sum(p.int*vr.int)+sum(p.int*(mn.int-mn.all)^2)

    sum = c(mean=mn.all,sd=sqrt(vr.all),qpred(probs,x,low=low,up=up))

      }

  # with observation boundaries
  if (low > -Inf & up < +Inf) {

    cp = cpdf(x)
    cpdf = cp$cpdf
    x = cp$int

    int.length=diff(c(low,x,up))
    mn.int = c(low,x) + int.length/2
    vr.int = int.length^2/12
    p.int = diff(c(0,cpdf,1))

    # use mixture formulas for mean and variance
    mn.all = sum(p.int*mn.int)
    vr.all = sum(p.int*vr.int)+sum(p.int*(mn.int-mn.all)^2)

    sum = c(mean=mn.all,sd=sqrt(vr.all),qpred(probs,x,low=low,up=up))
  }

  if (low ==0 & up == +Inf) {
    sum = spredsurv(time=x,event=NULL)
  }

    return(sum)
}

