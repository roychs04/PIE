#' Plot of estimates and respective probability intervals
#'
#' @param est k-vector of estimates
#' @param low k-vector of lower interval bounds
#' @param up k-vector of upper interval bounds
#' @param x k-vector of labels or numerical values
#' @param ref reference value separating negative and positive treatment effects
#' @param show.ref logical: default is \code{TRUE}, that is, the reference line is shown
#' @param show.est logical: default is \code{TRUE}, that is, the estimates are shown
#' @param est.shape shape of symbol for estimates
#' @param linewidth line width for lines connecting lower and upper interval bounds
#' @param pointsize for estimates
#' @param col.neg color for values less than *ref*
#' @param col.pos color for values larger than *ref*
#' @param xlab x-axis label
#' @param ylab y-axis label
#' @param xlim x-range
#' @param xbreaks vector of x-tick mark positions
#' @param ylim y-range
#' @param ybreaks vector of y-tick mark positions
#' @param flip.coord logical: default is \code{FALSE}, 
#' which means that interval lines are vertical. 
#' \code{flip.coord=TRUE} results in a for a forest plot like figure. 
#'
plot_estlowup = function(est,
                         low,
                         up,
                         x,
                        col.neg = "red",
                        col.pos = "blue",
                        ref=0,
                        show.ref = TRUE,
                        show.est = TRUE,
                        est.shape = 16,
                        linewidth=1,
                        pointsize=3,
                        xlab="",
                        ylab="",
                        xlim=NULL,
                        xbreaks=NULL,
                        ylim=NULL,
                        ybreaks = NULL,
                        flip.coord = FALSE
) {

  if (!is.null(ylim) & !(all(est>=ylim[1] & est<=ylim[2])))
    stop("all *est* values must be in range defined by *ylim*")

  k = length(est)
  if (missing(x))
    x = 1:k

  df <- data.frame(est=est, low=low,up=up)

  df.neg = NULL
  df.pos = NULL
  if (any(df$low<ref))
    df.neg = df[df$low<ref,]
  if (any(df$up>ref))
    df.pos = df[df$up>ref,]

  df.neg$y = x[df$low<ref]
  df.pos$y = x[df$up>ref]

  df.neg$up= ifelse(df.neg$up>ref,ref,df.neg$up)
  df.pos$low=ifelse(df.pos$low<ref,ref,df.pos$low)

  df.neg$negpos = col.neg
  df.pos$negpos = col.pos

  df = rbind(df.neg,df.pos)

  
  if (!flip.coord) {
    if (!is.null(ylim)) {
      df$up[df$up>ylim[2]] = ylim[2]
      df$up2 = (df$up==ylim[2])
      
      df$low[df$low<ylim[1]] = ylim[1]
      df$low2 = (df$low==ylim[1])
    }
    
    if (!is.null(est))
      fig <- ggplot(data=df, aes(x=y, y=est, ymin=low, ymax=up,
                                 fill = negpos
      ))
    if (is.null(est))
      fig <- ggplot(data=df, aes(x=y, ymin=low, ymax=up,
                                 fill = negpos
      ))
    
    
    fig = fig +
      geom_linerange(color=df$negpos,show.legend=FALSE,size=linewidth)
    
    
    if (show.est)
      fig = fig +
      geom_point(color = ifelse(df$est<=ref,col.neg,col.pos),
                 size=pointsize,shape=est.shape,show.legend=FALSE)
    
    fig = fig +
      xlab(xlab) +
      ylab(ylab)
    
    if (show.ref)
      fig = fig +
      geom_hline(yintercept=ref, lty=2)
    
    if (any(df$up2))
      fig = fig +
      annotate(geom="text", x=df$y[df$up2], y=df$up[df$up2],
               label=">",color=col.pos)
    
    if (any(df$low2))
      fig = fig +
      annotate(geom="text", x=df$y[df$low2], y=df$low[df$low2],
               
               label="<",color=col.neg)
  }
  
  if (flip.coord) {
    
    if (!is.null(xlim) & !is.null(xbreaks)) {
      fig = fig +
        scale_x_continuous(breaks=xbreaks,limits=xlim)
    }
    
    if (!is.null(xlim) & is.null(xbreaks)) {
      fig = fig +
        scale_x_continuous(limits=xlim)
    }
    
    if (!is.null(ylim) & !is.null(ybreaks)) {
      fig = fig +
        scale_y_continuous(breaks=ybreaks,limits=ylim)
    }
    
    if (!is.null(ylim) & is.null(ybreaks)) {
      fig = fig +
        scale_y_continuous(limits=ylim)
    }
    
    
    if (!is.null(ylim)) {
      df$up[df$up>ylim[2]] = ylim[2]
      df$up2 = (df$up==ylim[2])
      
      df$low[df$low<ylim[1]] = ylim[1]
      df$low2 = (df$low==ylim[1])
    }
    
    if (!is.null(est))
      fig <- ggplot(data=df, aes(x=est, y=y, xmin=low, xmax=up,
                                 fill = negpos
      ))
    
    if (is.null(est))
      fig <- ggplot(data=df, aes(y=y, xmin=low, xmax=up, fill = negpos
      ))
    
    fig = fig +
      geom_linerange(color=df$negpos,show.legend=FALSE,size=linewidth)
    
    
    
    if (show.est)
      fig = fig +
      geom_point(color = ifelse(df$est<=ref,col.neg,col.pos),
                 size=pointsize,shape=est.shape,show.legend=FALSE)
    
    fig = fig +
      xlab(xlab) +
      ylab(ylab)
    
    if (show.ref)
      fig = fig +
      geom_vline(xintercept=ref, lty=2)
    
    if (any(df$up2))
      fig = fig +
      annotate(geom="text", y=df$y[df$up2], x=df$up[df$up2],
               label=">",color=col.pos)
    
    if (any(df$low2))
      fig = fig +
      annotate(geom="text", y=df$y[df$low2], x=df$low[df$low2],
               label="<",color=col.neg)
    
    if (!is.null(xlim) & !is.null(xbreaks)) {
      fig = fig +
        scale_y_continuous(breaks=xbreaks,limits=xlim)
    }
    
    if (!is.null(xlim) & is.null(xbreaks)) {
      fig = fig +
        scale_y_continuous(limits=xlim)
    }
    
    if (!is.null(ylim) & !is.null(ybreaks)) {
      fig = fig +
        scale_x_continuous(breaks=ybreaks,limits=ylim)
    }
    
    if (!is.null(ylim) & is.null(ybreaks)) {
      fig = fig +
        scale_x_continuous(limits=ylim)
    }
    
  }

  fig = fig +
    scale_color_manual(values=c(col.neg,col.pos))

  fig = fig + theme_classic()

  fig = fig +
    theme(axis.title.x = element_text(size=rel(1.5))) +
    theme(axis.title.y = element_text(size=rel(1.5)))

  return(fig)
}
