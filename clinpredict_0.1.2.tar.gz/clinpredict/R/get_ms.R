
get_ms = function (lower, upper, probs = c(0.025, 0.975), 
                   distribution = c("normal", "lognormal", "logitnormal")[1]) 
{
  if (distribution == "lognormal") {
    U <- log(upper)
    L <- log(lower)
  }
  if (distribution == "normal") {
    U <- upper
    L <- lower
  }
  if (distribution == "logitnormal") {
    U <- log(upper/(1 - upper))
    L <- log(lower/(1 - lower))
  }
  sigma <- (U - L)/(qnorm(probs[2]) - qnorm(probs[1]))
  mu <- 0.5 * ((U + L) - sigma * (qnorm(probs[2]) + qnorm(probs[1])))
  return(c(mu, sigma))
}


