#' Cumulative distribution function (cdf) of gamma-poisson distribution
#'
#' gamma-poisson (overdispersed Poisson) distribution:
#' lambda ~ gamma(a,b), Y | lambda ~ poisson(lambda x E), Y ~ gamma-poisson(E,a,b)
#'
#' @param r number of successes for which the cdf wil lbe computed
#' @param E exposure time
#' @param a,b  parameters of Gamma distribution
#'
#' @examples
#' pgammapoisson(0:4,4,1,1)
#'
pgammapoisson <- function(r, E, a, b) {
  out = sapply(r, function(e) {
    rr <- seq(0, e)
    p = sum(dgammapoisson(rr, E, a, b))
    return(p)
  })
  return(out)
}
