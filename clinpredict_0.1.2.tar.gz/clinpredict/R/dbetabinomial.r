#' Density of beta-binomial distribution
#'
#' beta-binomial (overdispersed binomial)  distribution:
#' theta ~ beta(a,b), Y | theta ~ binomial(theta,n), Y ~ beta-binomilal(n,a,b)
#'
#' @param r number of successes; a scalar or vector
#' @param n sample size; a scalar or vector
#' @param a,b parameters of beta distribution
#'
#' @examples
#' predunif = dbetabinomial( 0:4, 4, 1, 1)
#' print(predunif)
#'
dbetabinomial <- function(r, n, a, b) {
  p <-
    lgamma(a + b) - lgamma(a) - lgamma(b) - lgamma(a + b + n) + lgamma(n +                                                                         1) - lgamma(r + 1) -
    lgamma(n - r + 1) + lgamma(a + r) + lgamma(b + n - r)
  d = exp(p)
  return(d)
}
