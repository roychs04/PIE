
#' Predictive cumulative distribution function using non-paramtric predictive distribution by Hill
#'
#' @param q vector of quantiles
#' @param x data vector
#' @param low lower bound for data
#' @param up upper bound for data
#'
#' @return vector of probabilities p for which pr(X<p) = q
#'
#' @examples
#' x = c(1,4,5,12)
#' ppred(q=c(8,12),x=x)
#'
ppred = function(q,
                 x,
                 low = -Inf,
                 up = +Inf) {
  x = sort(x)


  if (low > -Inf & up < +Inf) {

    cpdf = cpdf(x)
    x = cpdf$int
    cpdf = cpdf$cpdf

    p.pred = approx(x=c(low,x,up),y=c(0,cpdf,1),xout=q)$y
  }

    if (low == -Inf & up == +Inf) {

      cpdf = cpdf(x)
      x = cpdf$int
      cpdf = cpdf$cpdf

      p.pred = approx(x=x,y=cpdf,xout=q)$y

      ms = get_ms(
        lower = min(x),
        upper = max(x),
        probs = c(min(cpdf), max(cpdf)),
        distribution = "normal"
      )

      q.tail = q[q < min(x) | q > max(x)]
      q.tail = pnorm(q.tail, ms[1], ms[2])
      p.pred[is.na(p.pred)] = q.tail
    }

    if (low == 0 & up == +Inf) {
      p.pred = ppredsurv(q,time=x,event=NULL)
    }


    names(p.pred) = signif(q, 2)


  return(p.pred)
}


