
#' Quantile function of gamma-exponential distribution
#'
#' @param p vector of probabilities
#' @param a vector of interval-specific a parameters
#' @param b vector of interval-specific b parameters
#' @param int *vector of interval boundaries
#'
qpwgammaexp = function(p = 0.5, a, b, int) {

    int0 = c(0, int)
    n.int = length(int0)

    if (length(a) != n.int)
      stop("Length of a-vector bust be *n.int*")

    if (length(b) != n.int)
      stop("Length of b-vector bust be *n.int*")

    cp = ppwgammaexp(q=int, a, b, int)
    cp = c(0, cp, 1)

    ix = findInterval(p, cp)

    x = int0[ix]+((1 - cp[ix])/(1-p))^(1/a[ix])*b[ix]-b[ix]
    names(x) = p
      return(x)
  }


