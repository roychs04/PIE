
#' Title
#'
#' @param x the data, a vector of observations
#' @param breaks the interval boundaries
#'
#' @return the number of data points for each interval; note that -Inf and +Inf will
#' be added to the  \code{breaks} vector
#'

int_count = function(x, breaks) {
  b = sort(breaks)
  b = c(-Inf, b, Inf)
  ix = findInterval(x, b)
  return(sapply(1:(length(b) - 1), function(e)
    sum(ix == e)))
  
}

