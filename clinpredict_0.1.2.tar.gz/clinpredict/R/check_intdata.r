#' Checks required variables of interval data set for time-to-event analyses
#'
#' @param dat the data set, for which the presence of the variables \code{intlow, inthigh, nevents, exptime} will be checked. A warning will be issued if the smallest value of \code{intlow} is not \code{0} or the largest value of \code{inthigh} is not \code{Inf}.
#'
check_intdata = function(dat) {

  dat = as.data.frame(dat)
  nms.dat = names(dat)

  if (!is.element("intlow",nms.dat))
    stop("the variable *intlow* is missing in dataset")

  if (!is.element("inthigh",nms.dat))
    stop("the variable *inthigh* is missing in dataset")

  if (!is.element("nevents",nms.dat))
    stop("the variable *nevents* is missing in dataset")

  if (!is.element("exptime",nms.dat))
    stop("the variable *exptime* is missing in dataset")

  if (max(dat$inthigh) != Inf)
    warning("the largest value in *inthigh* should be Inf")
  if (min(dat$intlow) != 0)
    warning("the smallest value in *intlow* should be 0")

  return(NULL)
}

