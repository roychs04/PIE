#' Various formats for parameters of mixture distributions
#'
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distribution
#'
#' @return L list representation: each element is a three vector with weight \code{w}, \code{a}
#' and \code{b} parameter
#' @return M matrix representation with three columns (weight,\code{a},\code{b})
#' @return w weight vector
#' @return a vector of \code{a} parameters
#' @return b vector of \code{b} parameters
#' @return k the number of mixwure components
#'
#' @examples
#' # Examples
#' # single Beta
#' out1 = mix_pars( c(1,2))
#' print(out1)
#'
#' # singel Beta (with optional weight 1)
#' out2 = mix_pars( c(1,11,22))
#' print(out2)
#'
#' # mixture of two Betas, in list format
#' out3 = mix_pars( list(comp1=c(1,2,3),hist=c(3,4,5)) )
#' print(out3)
#'
#' # mixture of three Betas, in matrixlist format
#' out4 = mix_pars( rbind(c(1,2,3),c(1,3,2), c(3,4,5)) )
#' print(out4)
#'

mix_pars = function(wab) {
  wabL = NULL
  wabM = NULL

  if (is.list(wab) & length(wab)==1)
    wab = unlist(wab)

  if (!is.list(wab) & !is.matrix(wab))  {
    if (length(wab) == 2)
      wab = c(1, wab)
    wabL = list(wab)
    wabM = rbind(wab)
    colnames(wabM) = c("w", "a", "b")
    w = wabM[1]
    a = wabM[2]
    b = wabM[3]
  }

  if (is.list(wab)) {
    # list input: check consistency (equal length) for all components
    u = sapply(wab,function(e) length(e))
    if ( length(unique(u)) != 1 | (length(wab)>1 & all(u==2)))
      stop(("Elements of mixture components must be of length 3 (w,a,b)"))

    w = sapply(wab, function(e)
      e[1])
    if (abs(sum(w)-1) > 1e-6 ) {
      w = w / sum(w)
      warning("Weights are rescaled because their sum differs from 1 by more than 1e-6")
    }
    wabL = lapply(1:length(w), function(e)
      c(w[e], wab[[e]][2:3]))
    w = sapply(wabL, function(e)
      e[1])
    a = sapply(wabL, function(e)
      e[2])
    b = sapply(wabL, function(e)
      e[3])
    if (is.null(wabM)) {
      wabM = cbind(w, a, b)
      colnames(wabM) = c("w", "a", "b")
    }
    }
  if (is.matrix(wab)) {
    # wabMatrix a number of components x 3 matrix
    wabM = wab
    if (sum(wabM[, 1]) != 1) {
      warning("Weights (first column) are rescaled because their sum is not equal to 1")
      wabM[, 1] = wabM[, 1] / sum(wabM[, 1])
    }
    colnames(wabM) = c("w", "a", "b")
    w = wabM[, 1]
    a = wabM[, 2]
    b = wabM[, 3]
    if (is.null(wabL))
      wabL = lapply(1:nrow(wabM), function(e)
        wabM[e, ])
  }
  k = length(w)
  colnames(wabM) = c("w", "a", "b")
  nms = paste("mix", 1:k, sep = "")
  if (!is.null(names(wabL)))
    nms = names(wabL)
  if (!is.null(rownames(wabM)))
    nms = rownames(wabM)
  if (k > 1) {
    if (is.null(names(wabM)))
      rownames(wabM) = nms
    if (is.null(names(wabL)))
      names(wabL) = nms
  }
  return(list(
    L = wabL,
    M = wabM,
    w = w,
    a = a,
    b = b,
    k = k
  ))
}
