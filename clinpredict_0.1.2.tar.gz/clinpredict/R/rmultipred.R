#' Simulation of a random vector from the non-parametric Hill predictive distribution
#'
#' @param n.sim number of simulations
#' @param m dimension of vector; for \code{m=1}, use the
#' \code{rpred} function
#' @param x data vector
#' @param low lower bound for data
#' @param up upper bound for data
#'
#' @examples
#' x = c(1,2,5,12)
#' pred = rmultipred(n.sim=1000,m=5,x=x)
#' cor.pred = cor(pred)
#' # of interest: sum of 5 predictions
#' pred = apply(pred,1,sum)
#' # Note the correlation!
#' cor.pred
#' sim_sum(pred)
#' 
rmultipred = function(n.sim = 1,
                      m,
                      x,
                      low=-Inf,up=+Inf) {

  predall = sapply(1:n.sim, function(e) {
    pred = rep(NA, m)
    for (mm in 1:m) {
      new = rpred(1, x=x,low=low,up=up)
      pred[mm] = new
      x = c(x, new)
    }
    return(pred)
  })
  if (n.sim > 1)
    predall = t(predall)
  
  return(predall)
}

