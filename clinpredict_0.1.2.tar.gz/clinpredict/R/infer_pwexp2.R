#' @title Bayesian inference for two-group piecewise exponential data
#'
#' @description Bayesian inference to compare (difference, ratio or log-ratio) the median (or any other quantile) survival of
#' two groups assuming piecewise exponential data and Gamma priors for interval hazards
#'
#' @details
#' Group-wise conjugate Bayesian analyses (exponential sampling distribution,
#' Gamma prior distributions) are performed for each interval.
#' Posterior distributions for contrast for the quantiles (e.g. medians) are then obtained
#' by simulation.
#'
#' @param dat1 data set for first group: interval data given as number of events \code{(nevents)}, exposure time \code{(exptime)}, and interval boundaries \code{(intlow,inthigh)}
#' @param dat2 data set for second group
#' @param prior.lambda1 a 2-vector or \code{n.intx2} matrix with parameters \code{a} and \code{b}  of Gamma(a,b) prior distributions for the interval hazards.
#' If \code{NULL}, a default prior corresponding to one event (in total over all intervals)
#' is selected; that is, the first parameter is \code{a=1/n.int}. The other parameter \code{b} will be chosen such that the prior mean hazard \code{a/b}
#' equals the estimated pooled hazard over all intervals
#' @param prior.lambda2 parameters of Gamma distributions for interval hazards in group 2
#' @param prob the quantile of interest; default is 0.5 (median).
#' @param contrast contrast for comparing quantiles:
#' difference (\code{"diff"}), ratio (\code{"ratio"}) or log-ratio (\code{"logratio"})
#' @param cutoffs cutoffs defining intervals for contrast
#' @param n.sim number of simulations used to obtain the posterior distributions of the contrast
#'
#' @return prior.lambda: prior summaries for hazards in group 1 and 2
#' @return post.lambda: posterior summaries for hazards in group 1 and 2
#' @return prob.qntl: the probability defining the quantile (\code{=prob})
#' @return qntl1:  posterior summaries for quantile (default = median) of group 1
#' @return qntl2:  posterior summaries for quantile  of group 2
#' @return contrast.type: the selected contrast for the selected quantile, "diff", "ratio", or "logratio"
#' @return qntl.contrast: posterior summaries for selected contrast
#'
#' @examples
#'
#' # transform to interval data
#' leukint = ipd2int(obstime=leuk$obstime,event=leuk$event,X=subset(leuk,select="trt") )
#' infer_pwexp2(subset(leukint,trt==0),subset(leukint,trt==1),contrast="ratio")
#'
infer_pwexp2 = function(dat1,
                        dat2,
                        prior.lambda1 = NULL,
                        prior.lambda2 = NULL,
                        prob = 0.5,
                        contrast = c("diff", "ratio","logratio")[1],
                        cutoffs = ifelse(contrast == "ratio", 1, 0),
                        n.sim = 1e5
                        )
{
  if (length(prob) > 1)
    stop("*prob* must be a scalar")

  check_intdata(dat1)
  int10 = sort(unique(dat1$intlow))
  n.int1 = length(int10)
  int1 = int10[-1]
  haz1.est = sum(dat1$nevents) / sum(dat1$exptime)

  check_intdata(dat2)
  int20 = sort(unique(dat2$intlow))
  n.int2 = length(int20)
  int2 = int20[-1]
  haz2.est = sum(dat2$nevents) / sum(dat2$exptime)

  if (is.null(prior.lambda1))
    prior.lambda1 = matrix(rep(c(1/n.int1, 1/n.int1/haz1.est), each = n.int1), n.int1, 2)
  if (length(prior.lambda1) == 2)
    prior.lambda1 = matrix(rep(prior.lambda1, each = n.int1), n.int1, 2)
  if (is.null(prior.lambda2))

    prior.lambda2 = matrix(rep(c(1/n.int2, 1/n.int2/haz2.est), each = n.int2), n.int2, 2)
  if (length(prior.lambda2) == 2)
    prior.lambda2 = matrix(rep(prior.lambda2, each = n.int2), n.int2, 2)

  post.lambda1 = prior.lambda1 + 0
  for (j in 1:n.int1) {
    post.lambda1[j, ] = prior.lambda1[j, ] + c(dat1$nevents[j], dat1$exptime[j])
  }

  post1.sim = sapply(1:n.int1, function(e)
    rgamma(n.sim, post.lambda1[e, 1], post.lambda1[e, 2]))
  post1.sim = qpwexp(p=prob,post1.sim, int1)

  post.lambda2 = prior.lambda2 + 0
  for (j in 1:n.int2) {
    post.lambda2[j, ] = prior.lambda2[j, ] + c(dat2$nevents[j], dat2$exptime[j])
  }
  post2.sim = sapply(1:n.int2, function(e)
    rgamma(n.sim, post.lambda2[e, 1], post.lambda2[e, 2]))
  post2.sim = qpwexp(p=prob,post2.sim, int2)

  prior.lambda1 = rbind(prior.lambda1)
  prior.lambda2 = rbind(prior.lambda2)
  post.lambda1 = rbind(post.lambda1)
  post.lambda2 = rbind(post.lambda2)
  colnames(prior.lambda1) = c("gamma.a","gamma.b")
  colnames(prior.lambda2) = c("gamma.a","gamma.b")
  colnames(post.lambda1) = c("gamma.a","gamma.b")
  colnames(post.lambda2) = c("gamma.a","gamma.b")

  prior.lambda1 = cbind(sgamma(prior.lambda1[,1],prior.lambda1[,2]),prior.lambda1)
  prior.lambda2 = cbind(sgamma(prior.lambda2[,1],prior.lambda2[,2]),prior.lambda2)

  post.lambda1 = cbind(sgamma(post.lambda1[,1],post.lambda1[,2]),post.lambda1)
  post.lambda2 = cbind(sgamma(post.lambda2[,1],post.lambda2[,2]),post.lambda2)

  if (contrast == "diff") {
    post.con = post1.sim - post2.sim
    xlab = paste("difference of",
                 ifelse(prob == 0.5, "median", "quantile"),
                 "survival")
  }
  if (contrast == "ratio") {
    post.con = post1.sim / post2.sim
    xlab = paste("ratio of",
                 ifelse(prob == 0.5, "median", "quantile"),
                 "survival")
  }
  if (contrast == "logratio") {
    post.con = log(post1.sim)-log(post2.sim)
    xlab = paste("log-ratio of",
                 ifelse(prob == 0.5, "median", "quantile"),
                 "survival")
  }

  post1.sum = sim_sum(post1.sim[!is.na(post1.sim)])
  post2.sum = sim_sum(post2.sim[!is.na(post2.sim)])

  post.sum = sim_sum(post.con,cutoffs=cutoffs)

  # if (plot) {
  #   hist(
  #     post.con,
  #     xlab = xlab,
  #     ylab = "",
  #     axes = F,
  #     main = "",
  #     nclass = 20
  #   )
  #   axis(1)
  # }

  return(
    list(
      prior.lambdas = list(lambda1=prior.lambda1,lambda2=prior.lambda2),
      post.lambdas = list(lambda1=post.lambda1,lambda2=post.lambda2),
      prob.qntl = prob,
      qntl1 = post1.sum,
      qntl2 = post2.sum,
      qntl.contrast.type = contrast,
      qntl.contrast = post.sum
    )
  )
}
