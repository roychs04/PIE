#' Cumulative distribution function (cdf) of mixture of gamma distributions
#'
#' @param x values for which the cdf will be computed
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distributionwab
#'
pgammamix = function(x, wab) {
  wab = mix_pars(wab)
  d = 0
  for (j in 1:wab$k)
    d = d + wab$w[j] * pgamma(x, wab$a[j], wab$b[j])
  return(d)
}
