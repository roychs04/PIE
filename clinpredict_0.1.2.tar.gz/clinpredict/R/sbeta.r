#' Summaries of Beta distribution
#'
#' @param a,b parameters of Beta distribution; scalar or vectors
#' @param probs vector of probabilities for which quantiles will be obtained
#' @param cutoffs cutoff values defining intervals
#'
#' @examples
#' sbeta(1,6,cutoffs=0.25)
#' a = 1/10; b=2;
#' r = c(0,1,2); n = c(0,3,6)
#' sbeta(a+r,b+n-r,cutoffs=0.33)
#'
sbeta <-
  function(a,
           b,
           probs = c(0.025, 0.5, 0.975),
           cutoffs = NULL
) {
    a = 0 * b + a
    b = 0 * a + b

    ab = cbind(a, b)
    m = a / (a + b)
    s = sqrt(m * (1 - m) / (a + b + 1))
    qntls = apply(ab, 1, function(e)
      qbeta(probs, e[1], e[2]))
    if (length(probs) > 1)
      qntls = t(qntls)

    out = cbind(m, s, qntls)
    colnames(out) = c("mean", "sd", probs)

    # threshold (cutoff) probabilities
    if (!is.null(cutoffs)) {
      cutoffs.labels = int_labels(cutoffs,lower=0,upper=1)
      p.cut = sapply(cutoffs, function(e)
        pbeta(e, a, b))
      p.cut = matrix(p.cut,ncol=length(cutoffs))
      p.cut = cbind(0,p.cut,1)
      p.cut = t(apply(p.cut,1,diff))
      p.cut = cbind(p.cut)
      colnames(p.cut) = cutoffs.labels
      out = cbind(out, p.cut)
    }
    if (nrow(out) == 1)
      out = out[1,]

    return(out)
  }
