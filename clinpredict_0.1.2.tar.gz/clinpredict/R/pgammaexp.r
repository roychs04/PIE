#' Cumulative distribution function (cdf) of gamma-exponential distribution
#'
#' gamma-exponential (overdispersed exponential) distribution:
#' lambda ~ gamma(a,b), Y | lambda ~ exp(lambda), Y ~ gamma-exponential(a,b)
#'
#' @param x values for which the cdf will be computed
#' @param a,b parameters of Gamma distribution
#'
#' @examples
#' # cdf of gamma distribution and gamma-exponential distribution with same mean
#' a=2; b=1;
#' x = seq(0,5,length=1000);
#' plot(x,pexp(x,a/b),type="l");
#' lines(x,pgammaexp(x,a,b),lty=2)
#'
pgammaexp <- function(x, a, b) {
  p <- 1 - (b + x) ^ (-a) * b ^ a
  return(p)
}

