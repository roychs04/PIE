
#' Model search for piecewise-exponential distributions,
#' using the Akaike information criterion or the Bayesian
#' information criterion
#'
#' @param time n-vector of event and censoring times
#' @param event n-vector of event indicators: 1 for
#' event time, 0 for censoring time
#' @param int.cand vector of candidate interval boundaries to search
#' through; if  \code{NULL},  the set of candidate boundaries
#' is set to the 9 quantiles (10%,...,90%) of the event distribution,
#' which uses all event times but disregards censoring times.
#' @param n.int.max the maximum number of interval boundaries;
#' if  \code{NULL}, this is equal to the number of interval
#' boundaries in   \code{int.cand} (say \code{M}), which results in a
#' total number of possible models equal to \code{2^M}.
#'
#' @return
#' all AIC and BIC values for all possible models
#' by.int AIC and BIC values by values of number
#' of interval boundaries
#' sel the model with the smallest AIC or BIC
#'
pwexp_abic_search = function(time,
                             event,
                             int.cand = NULL,
                             n.int.max = NULL
) {
  if (is.null(int.cand)) {
    probs = seq(0, 1, length = 11)
    probs = probs[-1]
    probs = probs[-length(probs)]
    int.cand = quantile(time[event == 1], probs)
  }

  if (is.null(n.int.max))
    n.int.max = length(int.cand)

  out = list()
  for (j in 1:n.int.max) {
    a = t(combn(1:length(int.cand), j))
    aicbic = apply(a, 1, function(e)
      unlist(pwexp_abic(time, event, int.cand[e])))
    out[[j]] = list(int = a,
                    aic = aicbic[1,],
                    bic = aicbic[2,])
  }

  # results for exponential distribution
  aicbic.exp = pwexp_abic(time, event, NULL)
  out[[n.int.max + 1]] = list(int = "exponential",
                              aic = aicbic.exp$aic,
                              bic = aicbic.exp$bic)

  # results by number of intervals
  res.aic = lapply(out[1:n.int.max], function(e) {
    ix.min = which.min(e$aic)
    return(list(int = int.cand[e$int[ix.min, ]],
                aic = e$aic[ix.min]))
  })
  res.aic[[n.int.max + 1]] =
    list(int = NULL,
         aic = out[[n.int.max + 1]]$aic)

  res.bic = lapply(out[1:n.int.max], function(e) {
    ix.min = which.min(e$bic)
    return(list(int = int.cand[e$int[ix.min, ]],
                bic = e$bic[ix.min]))
  })
  res.bic[[n.int.max + 1]] =
    list(int = NULL,
         bic = out[[n.int.max + 1]]$bic)

  # select minimum over all models
  res2.aic = sapply(res.aic, function(e)
    e$aic)
  ix.min.aic = which.min(res2.aic)

  res2.bic = sapply(res.bic, function(e)
    e$bic)
  ix.min.bic = which.min(res2.bic)

  return(list(
    int.cand=int.cand,
    all = out,
    by.nint = list(aic = res.aic, bic = res.bic),
    sel = list(aic = res.aic[[ix.min.aic]],
               bic = res.bic[[ix.min.bic]])
  ))
}





