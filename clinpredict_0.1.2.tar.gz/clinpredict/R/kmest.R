#' Kaplan-Meier estimates
#'
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators ,1 for events and 0 for censored observations.
#' If \code{NULL}, no censoring is assumed
#' @param group n-vector of grouping values.
#' If \code{NULL}, a single group is assumed.
#'
#' @return a dataframe with estimates and 95%-intervals
#' if \code{group=NULL}, or a list of such dataframes otherwise.
#'
#' @examples
#' data(rats66)
#' kmest(rats66$time,rats66$event,rats66$trt)
#'
kmest = function(time,event=NULL,group=NULL) {
  if (is.null(event))
    event=rep(1,length(time))

  if (is.null(group)) {
    fit <- survfit(Surv(time, event) ~ 1)
    out = data.frame(time=fit$time,surv=fit$surv,low95=fit$lower)
  }

  if (!is.null(group)) {
    lbs = sapply(unique(group),function(e) unique(group[group==e]))
    out <- lapply(lbs,function(e) {
      fit = survfit(Surv(time[group==e], event[group==e]) ~ 1)
      out = data.frame(time=fit$time,surv=fit$surv,low95=fit$lower)
    }
    )
    names(out) = lbs
  }

  return(out)
}
