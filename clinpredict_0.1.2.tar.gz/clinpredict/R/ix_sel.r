
#' Indices function
#'
#' @param sel the name of the variable (parameter)
#' @param vnames a vector of variable names
#'
#' @return the indices of *sel* in *vnames*. See examples of exact matching, matching
#' elements in a vector, and matching elements in a matrix.
#'
#' @examples
#'
#' # Example 1: no matches
#' vn1 = "alpha"
#' ix_sel("beta",vn1)
#'
#' # Example 2: exact matching
#' vn2 = c("alpha","beta")
#' ix_sel("beta",vn2)
#'
#' # Example 3: matching elements in a vector
#' vn3 = c("alpha","beta[1]","beta[2]")
#' ix_sel("beta",vn3)
#'

#' # Example 4: matching elements in a matrix (split by columns)
#' vn4 = c("alpha","beta[1,1]","beta[1,3]","beta[2,2]")
#' ix_sel("beta",vn4)
#'
#' # Example 5: matching elements in a vector
#' vn5= c("alpha","beta[1,1]","beta[2,1]")
#' ix_sel("beta",vn5)
#'
#'
ix_sel = function(sel,vnames,matrix2list=FALSE) {
  ns <- nchar(sel)
  # check for exact name matching
  match1 <- sapply(vnames, function(e)
    (substring(paste(e, sel, sep = ""), 1, ns) == sel)  &
      (nchar(e) == ns)
  )
  # check for matching matrix of vector, i.e., with "[" following sel
  match2 <- sapply(vnames, function(e)
    (substring(paste(e, sel, sep = ""), 1, ns) == sel)  &
      (substring(e, ns + 1, ns + 1) == "[")
    # &
    #   (!is.element(",",strsplit(e,split="")[[1]]))
    )
  if (matrix2list)
  match3 <- sapply(vnames, function(e)
      (substring(paste(e, sel, sep = ""), 1, ns) == sel)  &
      (substring(e, ns + 1, ns + 1) == "[") &
      (is.element(",",strsplit(e,split="")[[1]]))
  )
  else
    match3 <- sapply(vnames,function(e) FALSE)

  out = NULL

  if (any(match1)) {
    out = (1:length(vnames))[match1]
    out = list(out)
    names(out) = sel
  }

  if (any(match2)) {
    out = (1:length(vnames))[match2]
    out = list(out)
    names(out) = sel
  }

  if (any(match3)) {
    sss = sapply(vnames,function(e) strsplit(e,split=",")[[1]][1])
    sss=sss[match3]
    sss = unique(sss)
    ssslab=lapply(sss,function(e) strsplit(e,split="")[[1]])
    ssslab=lapply(ssslab,function(e) paste(e[e != "["],collapse=""))

    out = lapply(sss,function(ee) {
      match3 <- sapply(vnames,
                       function(e)
                         substring(e,1,nchar(ee)) == ee
                       )
      return(  (1:length(vnames))[match3])
      }
      )
    names(out) = ssslab
  }

  if (is.list(out)) {

    outvec = as.vector(sapply(out,function(e) vnames[e]))
    g1 = sapply(outvec,function(e) match(",",strsplit(e,"")[[1]]))
    g2 = sapply(1:length(outvec),function(e) substring(outvec[e],g1[e]+1,g1[e]+1))

    if (length(unique(g2))==1)
      out = as.vector(sapply(out,function(e) e))
  }

  return(out)
}


