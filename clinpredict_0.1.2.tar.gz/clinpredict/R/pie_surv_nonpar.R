
#' Predictive individual effect distribution for survival data
#'
#' @param data dataframe with the variables
#' \code{time} (event and censoring5 times),
#' \code{event} (event indicator, \code{1} for events, \code{0} for censoring),
#' and \code{trt} (\code{0} for control, \code{1} for treatment)
#' @param rank.method Method for predictive calculations.
#' The default is \code{"fixed"} with \code{rank.par=1}, that is, strict rank
#' rank preservation (the Lehmann-Doksum model). Alternatives
#' are \code{"beta"} or \code{"logitnormal"} (with respective parameters
#' given in \code{rank.par}), which allow for a prior distribution of the
#' rank preservation factor in the interval (0,1).
#' @param rank.par the rank-preservation fraction (if \code{fixed}) or the
#' parameters of the Beta or logit-normal distribution otherwise.
#' @param trial.label trial label (only used for caption headers)
#' @param T.label the label for the testgroup
#' @param C.label the label for the control group
#' @param time.unit the time unit (only used for Kaplan-Meier plots)
#' @param pie.gain.cutoffs the interval with for the histogram of the predictive
#' individual effect distribution
#' @param C.col color for control group
#' @param T.col color for testgroup
#' @param n.pred simulation sample size for predictive individual effect
#' distribution
#' @param save.sim logical: if \code{TRUE}, simulated values for
#' control and testwill be saved; default is \code{FALSE}
#'
#' @return
#' rank.pres
#' int interval boundaries for piecewise exponential analyses
#' of control and treatment
#' coxPH the output object from the Cox proportional hazards analysis
#' logrank  the output object from the logrank analysis
#' pwexp
#' sim
#' marg
#' pie
#' pie.gain
#' tables_knitr
#' figures
#'
#' @examples
#'

pie_surv_nonpar = function(data,
                         rank.method = c("fixed", "beta", "logitnormal")[1],
                         est.method = c("BerlinerHill","KaplanMeier")[1],
                         rank.par = 1,
                         #yC.cond = NULL,
                         trial.label = "",
                         T.label = "treatment",
                         C.label = "control",
                         gain.label = "survival gain",
                         time.unit = "",
                         pie.gain.cutoffs = NULL,
                         pie.cutoffs = 0,
                         C.col = "red",
                         T.col = "blue",
                         n.pred = 1e4,
                         show.iter = 1e6,
                         save.sim = FALSE) {
  CT.label = c(C.label, T.label)


  # prepare data for Kaplan-Meier plots
  data$trt = as.factor(data$trt)
  data$group = ifelse(data$trt == 0, C.label, T.label)
  data$group = factor(data$group, levels = c(C.label, T.label))

  # Kaplan-Meier plot
  fig.km1 = plot_km(
    data = data,
    ci = FALSE,
    col = c(C.col, T.col),
    time.unit = time.unit
  )


  # Kaplan-Meier plot with package survminer

  fit <- survfit(Surv(time, event) ~ trt, data = data)

  # log-rank test (one sided p-value)
  test. <- survdiff(Surv(time, event) ~ trt, data = data)
  logrank <- round(1 - pnorm(sqrt(test.$chisq)), 4)

  #Cox regression
  cox <- coxph(Surv(time, event) ~ trt, data = data)
  hr <- round(exp(cox$coefficients), 2)
  hrl <- round(exp(confint(cox)[1]), 2)
  hru <- round(exp(confint(cox)[2]), 2)

  fig.km <- ggsurvplot(
    fit,
    data = data,
    pval = FALSE,
    pval.method = TRUE,
    # Add p-value &  method name
    surv.median.line = "none",
    # Add median survival lines
    legend.title = "",
    # Change legend titles
    legend.labs = c(C.label, T.label),
    # Change legend labels
    palette = "jco",
    # Use JCO journal color palette
    risk.table = TRUE,
    # Add No at risk table
    cumevents = FALSE,
    # Add cumulative No of events table
    tables.height = 0.15,
    # Specify tables height
    tables.theme = theme_cleantable(),
    # Clean theme for tables
    tables.y.text = FALSE,
    # Hide tables y axis text
    xlab         = time.unit,
    ylab = "survival probability",
    newpage      = FALSE
  )

  fig.km$plot <- fig.km$plot +
    ggplot2::annotate(
      "text",
      x = 0.75 * max(data$time[data$event == 1]),
      y = 0.85,
      label = paste("log-rank p-value = ", logrank, sep = "")
    ) +
    ggplot2::annotate(
      "text",
      x = 0.75 * max(data$time[data$event == 1]),
      y = 0.9,
      label = paste("hazard ratio (95% CI)=", hr, " (", hrl, ",", hru, ")", sep =
                      "")
    ) +
    theme(text = element_text(size = 25))

  # data for piecewise exponential analyses of control and treatment
  dataC = subset(data, trt == 0)
  dataT = subset(data, trt == 1)

  # Predictive individual effect distribution

  method = "inversion"
  sum.p.sim = NULL
  sum.corr = NULL
  if (method == "inversion") {
    if (rank.method == "fixed") {
      sum.p.sim = rank.par

      if (!is.element(rank.par, c(1, 0.95, 0.9, 0.8)))
        stop("Supported values for *rank.par* are 1, 0.95, 0.9, and 0.8")

      if (is.element(rank.par, c(1, 0.95, 0.9, 0.8)))  {
        if (rank.par == 1)
          corr = 1
        if (rank.par == 0.95)
          corr = 0.9875
        if (rank.par == 0.9)
          corr = 0.951
        if (rank.par == 0.8)
          corr = 0.808

        sum.corr = corr

        zC = rnorm(n.pred, 0, 1)
        zT = rnorm(n.pred, zC * corr, sqrt(1 - corr ^ 2))
        uC = pnorm(zC)
        uT = pnorm(zT)
      }
    }

    if (rank.method == "beta") {
      p.sim = rbeta(n.pred, rank.par[1], rank.par[2])
      p.sim = 0.5 + 0.5 * p.sim
      sum.p.sim = sim_sum(p.sim)

      # get correlation-rank.preservation percentage data
      x = dget("rankpreserve.dmp")

      sim = t(sapply(1:length(p.sim), function(e) {
        ix = which.min(abs(x$p.rankpreserve - p.sim[e]))
        out = x[ix, ]
        return(out)
      }))
      corr = unlist(sim[, 1])
      sum.corr = sim_sum(corr)

      zC = rnorm(n.pred, 0, 1)
      zT = rnorm(n.pred, zC * corr, sqrt(1 - corr ^ 2))

      uC = pnorm(zC)
      uT = pnorm(zT)
    }

    if (rank.method == "logitnormal") {
      p.sim = expit(rnorm(n.pred, rank.par[1], rank.par[2]))
      p.sim = 0.5 + 0.5 * p.sim
      sum.p.sim = sim_sum(p.sim)

      # get correlation-rank.preservation percentage data
      x = dget("rankpreserve.dmp")

      sim = t(sapply(1:length(p.sim), function(e) {
        ix = which.min(abs(x$p.rankpreserve - p.sim[e]))
        out = x[ix, ]
        return(out)
      }))
      corr = unlist(sim[, 1])
      sum.corr = sim_sum(corr)

      zC = rnorm(n.pred, 0, 1)
      zT = rnorm(n.pred, zC * corr, sqrt(1 - corr ^ 2))

      uC = pnorm(zC)
      uT = pnorm(zT)
    }

    # percentage of cases fulfilling rank preservation
    rank.pres.frac = mean((zC > 0 & zT > 0) | (zC <= 0 & zT <= 0))


    # # now simulate predictive control and testtimes
    # yC.pred = sapply(1:length(uC), function(e)
    #   qpwexp(uC[e], lambda = lambdaC.sim[e,], int = intC))
    # yT.pred = sapply(1:length(uT), function(e)
    #   qpwexp(uT[e], lambda = lambdaT.sim[e,], int = intT))

  }


  timeC = dataC$time
  eventC = dataC$event

  timeT = dataT$time
  eventT = dataT$event

  # pie.cond = NULL
  # if (!is.null(yC.cond)) {
  #   pie.cond = matrix(NA, n.pred, length(yC.cond))
  #   colnames(pie.cond) = paste(C.label, "=", yC.cond, sep = "")
  # }

  # yC.pred = surv_nonpar(time=timeC,event=eventC,probs=uC,method=est.method)$qntls
  # yT.pred = surv_nonpar(time=timeT,event=eventT,probs=uT,method=est.method)$qntls

  yC.pred = qpredsurv(uC,timeC,eventC)
  yT.pred = qpredsurv(uT,timeT,eventT)

    # conditional distribution for assumed yC values
    # pie.cond = NULL
    # if (!is.null(yC.cond))   {
    # }

  marg.sum = rbind(sim_sum(yC.pred),
                   sim_sum(yT.pred))
  row.names(marg.sum) = CT.label

  pie = yT.pred - yC.pred
  pie.sum = sim_sum(pie, cutoffs = pie.cutoffs)
  rownames(pie.sum) = NULL

  # if (!is.null(pie.cond))
  #   pie.cond = sim_sum(pie.cond, cutoffs = pie.cutoffs)

  # knitr tables: for marginal distributions, predictive individual
  # effect distribution, and conditional effect distribution
  tab.marg = knitr::kable(
    marg.sum,
    row.names = TRUE,
    caption =
      paste(
        trial.label,
        ": predictive ",
        C.label,
        " and ",
        T.label,
        " survival times",
        sep = ""
      )
  )

  tab.pie = knitr::kable(
    pie.sum,
    caption =
      paste(trial.label, ": predictive individual effect (T-C)"),
    row.names = FALSE
  )

  # tab.pie.cond = NULL
  # fig.cond = NULL
  # if (!is.null(pie.cond)) {
  #   tab.pie.cond = knitr::kable(
  #     pie.cond,
  #     row.names = TRUE,
  #     caption = paste(
  #       trial.label,
  #       ": conditional predictive survival gain (",
  #       T.label,
  #       "--",
  #       C.label,
  #       ")",
  #       sep = ""
  #     )
  #   )
  #
  #   fig.cond = ggplot()
  #   for (j in 1:nrow(pie.cond)) {
  #     dsj = data.frame(x = rep(yC.cond[j], 2), y = pie.cond[j, c(3, 5)])
  #     fig.cond = fig.cond +
  #       geom_line(data = dsj, aes(x = x, y = y), col = T.col)
  #   }
  #   ds.est = data.frame(x = yC.cond, est = pie.cond[, 1])
  #   fig.cond = fig.cond +
  #     geom_point(ds.est, mapping = aes(x = x, y = est), col = T.col) +
  #     xlim(c(0, max(yC.cond) * 1.1)) +
  #     ylim(range(pie.cond[, c(3, 5)])) +
  #     xlab(ifelse(
  #       time.unit == "",
  #       C.label,
  #       paste(C.label, " (", time.unit, ")", sep = "")
  #     )) +
  #     ylab(gain.label) +
  #     geom_abline(slope = 0,
  #                 intercept = 0,
  #                 linetype = 3)
  #
  # }

  # interval probabilities for predictive individual effect
  # tables and figure

  # default values
  # default values
  if (is.null(pie.gain.cutoffs)) {

    r.pie = diff(quantile(pie, c(0.1, 0.9)))
    if (r.pie < 5)
      bin = 0.5
    if (r.pie >= 5 & r.pie < 100)
      bin = floor(r.pie / 10) + 1
    if (r.pie >= 5 & r.pie > 100)
      bin = (floor(r.pie / 100) + 1) * 10

    seq.pos = seq(0,floor(max(abs(pie))/bin),by=bin)
    seq.neg = sort(-seq.pos[-1])
    seq.all = c(seq.neg,seq.pos)

    seq.all = seq.all[seq.all>quantile(pie,0.05) &
                        seq.all<quantile(pie,0.95)]
    if (0<min(seq.all))
      seq.all = seq(0,max(seq.all),by=bin)
    if (0>max(seq.all))
      seq.all = seq(min(seq.all),0,by=bin)
    pie.gain.cutoffs = seq.all
  }

  pie.gain.sum = pie_gain(pie,cutoffs=pie.gain.cutoffs)

  tab.pie.gain = knitr::kable(
    pie.gain.sum,
    caption =
      paste(
        trial.label,
        ": cumulative predictive individual effect distribution",
        sep = ""
      )
  )

  negpos = pie.gain.cutoffs>=0
  if (min(pie.gain.cutoffs)>0)
    negpos = c("TRUE",negpos)
  else
    negpos = c("FALSE",negpos)

  y = pie.gain.sum
  x = names(pie.gain.sum)
  x = factor(x,levels=x)
  fig.gain = plot_bar(y=y,group=x,
                      subgroup=negpos,
                      col.subgroup=c(C.col, T.col),
                      xlab=gain.label,
                      ylab="probability",
                      show.legend=FALSE,
                      ylim=c(0,1))

  sel = pie.gain.sum>0.005
  fig.gain = fig.gain  +
    ggplot2::annotate(
      "text",
      x = names(pie.gain.sum[sel]),
      y = unlist(pie.gain.sum)[sel] + 0.03,
      label = round(unlist(pie.gain.sum)[sel], 2),
      size=3.5
    )

  fig.gain = fig.gain + theme_classic()

  # fig.gain = fig.gain +
  #   theme(axis.title.x = element_text(size=rel(1.5))) +
  #   theme(axis.title.y = element_text(size=rel(1.5)))


  if (!save.sim)
    sim.out =   "simulated values not saved: set *save.sim=TRUE*"
  if (save.sim) {
    sim.out = data.frame(control = yC.pred, test= yT.pred)
    row.names(sim.out) = NULL
  }


  return(
    list(
      rank.pres = list(fraction = sum.p.sim,
                       gauss.copula.corr = sum.corr),
      coxPH = cox,
      logrank = logrank,
      sim = sim.out,
      marg = marg.sum,
      pie = pie.sum,
      pie.gain = pie.gain.sum,
      # pie.cond = pie.cond,
      tables_knitr = list(
        marg = tab.marg,
        pie = tab.pie,
        # pie.cond = tab.pie.cond,
        pie.gain = tab.pie.gain
      ),
      figures = list(
        km = fig.km,
        pie.gain = fig.gain
        # pie.cond = fig.cond
      )
    )
  )
}


