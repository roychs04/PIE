#' Replacement of variable names
#'
#' @param vnames vector of variable names
#' @param old variable name to be replaced
#' @param new new variable name
#'
#' @examples
#'
#' vnames1 = c("alpha","theta1","theta","theta[2,1]")
#' replace_parstr(vnames1,"pi","theta")
#' replace_parstr(vnames1,"pi")
#'
#' vnames2 = c("theta1","theta[1,1]","theta[1,2]")
#' replace_parstr(vnames2,"pi")
#'
#' vnames3 = c("theta1")
#' replace_parstr(vnames3,"pi")

replace_parstr = function(vnames, new, old="") {


  if (is.null(vnames))
    repvnames = NULL

  if ( old=="" & !is.null(vnames)) {
    nch = min(sapply(vnames,nchar))
    all.same = rep(NA,nch)
    for (j in 1:nch) {
      all.same[j] = length(unique(sapply(vnames,function(e) substring(e,1,j))))==1
    }
    old = paste( strsplit(vnames[1],"")[[1]][all.same],collapse="")

    vecmat = strsplit(old,"")[[1]] == "["
    if (any(vecmat))
      old = substring(old,1,which(vecmat)-1)
  }


  if (!is.null(vnames) & (old !="")) {
    repvnames =   sapply(vnames, function(e) {
      if (substring(e,1,nchar(old))==substring(old,1,nchar(old)))
        paste(new,substring(e,nchar(old)+1,nchar(e)),sep="")
      else
        repvnames = e
    }
    )
    names(repvnames) = NULL
  }
  else {
    warning("no common name in *vnames* to replace")
  }
    if (length(vnames)==1)
      repvnames = new

  return(repvnames)
}
