#' Random numbers from gamma-exponential distribution
#'
#' gamma-exponential (overdispersed exponential) distribution:
#' lambda ~ gamma(a,b), Y | lambda ~ exp(lambda), Y ~ gamma-exponential(a,b)
#'
#' @param n.sim Number of simulations
#' @param a,b parameters of gamma-exponential distribution
#'
#' @examples
#' a = 2; b=1
#' rrr = rgammaexp(1e6,a,b)
#' x = quantile(rrr,c(0.25,0.95))
#' x
#' pgammaexp(x,a,b)
#' sim_sum(rrr)
#' sgammaexp(a,b)

rgammaexp <- function(n.sim=1, a, b) {
  lambda = rgamma(n.sim, a, b)
  x = rexp(n.sim, lambda)
  return(x)
}






