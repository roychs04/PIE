#' Extraction of simulated values from JAGS/WinBUGS analysis
#'
#' @param pars vector of parameter names for which simulated values wil be extracted
#' @param out matrix of simulated values from JAGS/WinBUGS output object
#' @param matrix2list
#'
sim_jagswb <-  function(pars,
                        out,
                        matrix2list = FALSE) {
  allout = list()
  for (j in 1:length(pars)) {

    parsj = pars[j]
    out = cbind(out)
    vnames <- colnames(out)
    out.ix = ix_sel(parsj, vnames, matrix2list = matrix2list)

    if (is.list(out.ix))
      out.simsum = lapply(out.ix, function(e)
        out[, e])
    else
      out.simsum = out[, out.ix]

    allout[[j]] = out.simsum
  }

  names(allout) = pars

  # allout = lapply(allout, function(e) {
  #   if (is.list(e) & length(e) == 1)
  #     return(e[[1]])
  #   else
  #     return(e)
  # })

  return(allout)
}
