#' Density of mixture of beta distributions
#'
#' @param x vector of values for which the density will be computed
#' @param wab a list, matrix, or vector of values (for a single Beta distribution)
#' that specify the (mixture) probability distributionwab
#'
dbetamix = function(x, wab) {
  wab = mix_pars(wab)
  d = 0
  for (j in 1:wab$k)
    d = d + wab$w[j] * dbeta(x, wab$a[j], wab$b[j])
  return(d)
}



