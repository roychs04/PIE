#' Non-parametric cumulative predictive distribution function by Berliner-Hill
#'
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators, 1 for events and 0 for censored observations. If \code{NULL},
#' no censoring is assumed
#' @param version original version ("BerlinerHill") or modified version ("pwgammaexp")#'
#'
#' @return int interval boundaries defined by event times
#' @return lambda piecewise exponential interval hazards
#' @return Berliner-Hill cumulative predictive distribution function
#'
#' @examples
#' data(km)
#' cpdfsurv(km$time,km$event,version="BerlinerHill")
#' cpdfsurv(km$time,km$event)
#' cpdfsurv(km$time)
#'
cpdfsurv = function(time,
                     event=NULL,
                     version=c("BerlinerHill","pwgammaexp")[2]) {

  n = length(time)

  # for rightcensored data
  if (is.null(event))
    event = rep(1,n)

  r = order(time)
  time = time[r]
  event = event[r]

  if (version=="BerlinerHill") {
    time1 = time[event == 1]


    if (length(time1) != length(unique(time1))) {
      warning("\n Ties have been detied for Berliner-Hill distribution...
              Recommendation: use *pwgammaexp* version instead.")

      L = min(diff(c(0,sort(unique(time[event==1])))))

      ix.ties = sapply(time1,function(e) sum(time1==e)>1)
      time1.ties = time1[ix.ties]
      time1.ties = unique(time1.ties)

      for (j in 1:length(time1.ties)) {
        nn = sum(time1==time1.ties[j])
        ss = seq(0,by=L/10,length=nn)
        ss = ss-mean(ss)
        time1[time1==time1.ties[j]] = time1[time1==time1.ties[j]]+ss
      }

    }

    n.int = length(time1) + 1

    time2 = NULL
    if (any(event == 0))
      time2 = time[event == 0]

    b = time1
    # Berliner and Hill, JASA 1988
    cc = rep(0, n.int)
    if (any(event == 0))
      cc = int_count(time2, b)

    # C
    c.cum = cumsum(cc)
    i = 0:(n.int - 1)
    lam = 1 / (n - (i - 1) - c.cum)

    p = rep(NA, n.int)
    p[1] = lam[1]
    p[-1] = cumprod(1 - lam[1:(n.int - 1)]) * lam[2:n.int]
    surv = 1 - cumsum(p)
    surv = surv[-length(surv)]
    cpdf = 1-surv
    names(surv) = paste(">", time1, sep = "")
    names(cpdf) = paste("<=", time1, sep = "")


  # get pwexp parameters
  int = time1
  p = diff(c(0,cpdf))

  n = length(int)
    if (n==1)
    lambda = -log(1-cpdf)/int

  if (n>1) {
    lambda = rep(NA,n+1)

    lambda[1] = -log(1-p[1])/int[1]

    for (j in 2:n) {
      lambda[j] = -log( (1-cpdf[j])/(1-cpdf[j-1]) ) /(int[j]-int[j-1])
    }
    lambda[n+1] = sum(event)/sum(time)
  }

    out = list(int=int,lambda=lambda,cpdf=cpdf)
  }


  # piecewsie gamma-exponential version
  if (version=="pwgammaexp") {
    int2 = sort(unique(time[event==1]))
    n.int2 = length(int2)+1

    # get interval data
    int2.data = ipd2int(time,event,int=int2)

    b = int2.data$exptime
    a = int2.data$nevents

    # change last (a,b), with a=1
    # new version
    time1 = sort(unique(time[event==1]))
    m = length(time1)
    a1 = a[1:m]
    b1 = b[1:m]
    coeff = lm(log(b1/a1) ~ 1+time1,weight=a1)$coeff
    fit = exp(coeff[1]+coeff[2]*time1)
    b.last = fit[m]

    a[n.int2] = 1
    b[n.int2] = b.last

    # old version
    # haz.est = sum(event)/sum(time)
    # a[n.int2] = 1
    # b[n.int2] = 1/haz.est

    cp =    ppwgammaexp(int2,a,b,int2)
    names(cp) =    paste("<=", int2, sep = "")


    out = list(int=int2,a=a,b=b,cpdf=cp)
    }

  return(out)
}




