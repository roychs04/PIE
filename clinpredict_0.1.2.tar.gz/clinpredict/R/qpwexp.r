#' Quantile function of piecewise exponential distribution
#'
#' @param p scalar or vector of probabilities
#' @param lambda \code{n.int+1}-vector or \code{k x n.int+1} matrix of exponential parameters
#' @param int \code{n.int}-vector of interval boundaries
#' @param simsum logical: if \code{TRUE}, simulation summaries will be given (defaults to \code{FALSE})
#'
#' @examples
#' # two intervals
#' int = 3
#'
#' # single parameter vector
#' lambda1 = c(0.1,0.2)
#' qpwexp(p=c(0.1,0.5,0.9),lambda1,int)
#' head(qpwexp(runif(1000),lambda1,int))
#' qpwexp(runif(1000),lambda1,int,simsum=TRUE)
#'
#' # for more than one parameter vector
#' lambda2 = c(0.09,0.22)
#' lambda = rbind(lambda1,lambda2)
#' qpwexp(p=c(0.1,0.5,0.9),lambda,int)
#'
#' # simulated values from posterior
#' lambda.sim = cbind(runif(1e4,0.09,0.11),runif(1e4,0.15,0.20))
#' head(qpwexp(p=c(0.1,0.5,0.9),lambda.sim,int))
#' qpwexp(p=c(0.1,0.5,0.9),lambda.sim,int,simsum=TRUE)
#'
qpwexp = function(p = 0.5,
                  lambda,
                  int,
                  simsum = FALSE) {
  # new, much faster version, allowing for a matrix of lambda vectors (each row a lambda)

  check_lambdaint(lambda, int)

  if (is.vector(lambda)) {

    cp = ppwexp(int, lambda, int)


    cp[is.nan(cp)] = 0

    int0 = c(0, int)
    cp = c(0, cp, 1)

    ix = findInterval(p, cp)

    x = int0[ix] - log(1 - (p - cp[ix]) / (1 - cp[ix])) / lambda[ix]

    if (simsum)
      return(sim_sum(x))
    if (!simsum) {
      names(x) = p
      return(x)
    }
  }

  if (is.matrix(lambda)) {
    nr = nrow(lambda)

    int0 = c(0, int)
    n.int = length(int0)
    L = diff(int0)
    L = c(L, Inf)
    int0 = c(int0, Inf)

    qntl = NULL

    # survival for each interval boundary (0 included)
    surv = matrix(1, nrow(lambda), n.int)
    for (j in 1:(n.int - 1)) {
      surv[, j + 1] = surv[, j] * exp(-lambda[, j] * L[j])
    }
    for (j in 1:length(p)) {
      # find interval where qntl is
      int.qntl = apply(surv, 1, function(e)
        sum(e > 1 - p[j]))
      surv.sel = surv[cbind(1:nr, int.qntl)]
      lambda.sel = lambda[cbind(1:nr, int.qntl)]
      qntl = cbind(qntl, int0[int.qntl] - (log(1 - p[j]) - log(surv.sel)) /
                     lambda.sel)
    }

    if (!simsum)
      colnames(qntl) = p
    if (simsum) {
      qntl = sim_sum(qntl)
      qntl = rbind(qntl)
      rownames(qntl) = p
    }
    x = qntl[, ]
  }

  return(x)
}

