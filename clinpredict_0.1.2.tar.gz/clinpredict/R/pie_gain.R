#' Cumulative probabilities of predictive individual effect (PIE) gains and losses
#'
#' @param x vector of PIE values
#' @param ref reference value, which divides gains and losses;
#' default is zero, assuming that PIE is a difference
#' @param cutoffs vector of threshold values for gains (>ref) and 
#' losses (<=ref). 
#'
#' @return Probabilities that PIE is greater than cutoffs 
#' greater (>) than \code{ref} (pr(PIE>cutoff) or smaller (<=) than cutoffs smaller
#' than \code{ref} (pr(PIE<=cutoff)
#'
#' @examples
#' x = sample( -50:200,size=1000,replace=TRUE)
#' pie_gain(x)
#' cutoffs = c(-25,0,25,50,100)
#' pie_gain(x,cutoffs=cutoffs)
#' 
pie_gain = function(x,ref=0,cutoffs=ref) {
  cuts = unique(cutoffs)
  cuts = sort(cuts)

  cuts1 = cuts[cuts<=ref]
  cuts2 = cuts[cuts>=ref]

  pie1 = sapply(cuts1,function(e) mean(x<=e))
  names(pie1) = paste("<=",cuts1,sep="")
  pie2 = sapply(cuts2,function(e) mean(x>e))
  names(pie2) = paste(">",cuts2,sep="")
  
  pie.gain = c(pie1,pie2)
  return(pie.gain)
}



