#' Summaries of Gamma distribution
#'
#' @param a,b parameters of Gamma distribution (scalar or vector)
#' @param probs vector of probabilities for which quantiles will be obtained
#' @param cutoffs cutoff values defining intervals
#'
#' @examples
#' sgamma(1,1,cutoffs=c(0.69,3.5))
#' sgamma(1,c(1,2),cutoffs=c(0.69,3.5))
#'
sgamma <-
  function(a,
           b,
           probs = c(0.025, 0.5, 0.975),
           cutoffs = NULL
  )
  {
    a = 0 * b + a
    b = 0 * a + b

    ab = cbind(a, b)
    m = a / b
    s = sqrt(a) / b
    qntls = apply(ab, 1, function(e)
      qgamma(probs, e[1], e[2]))
    if (length(probs) > 1)
      qntls = t(qntls)

    out = cbind(m, s, qntls)
    colnames(out) = c("mean", "sd", probs)

    # threshold (cutoff) probabilities
    if (!is.null(cutoffs)) {
      cutoffs.labels = int_labels(cutoffs,lower=0,upper=NULL)
      p.cut = sapply(cutoffs, function(e)
        pgamma(e, a, b))
      p.cut = matrix(p.cut,ncol=length(cutoffs))
      p.cut = cbind(0,p.cut,1)
      p.cut = t(apply(p.cut,1,diff))
      p.cut = cbind(p.cut)
      colnames(p.cut) = cutoffs.labels
      out = cbind(out, p.cut)
    }
    if (nrow(out) == 1)
      out = out[1,]

    return(out)
  }
