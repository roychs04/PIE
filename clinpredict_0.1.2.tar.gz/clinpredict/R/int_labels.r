#' Labels for intervals defined by cutoffs
#'
#' @param cutoffs k cutoff values defining k+1 intervals
#' @param lower lower bound: if \code{NULL}, the first label will be "<cutoffs[1]"
#' @param upper upper bound: if \code{NULL}, the last  label will be ">=cutoffs[last]"
#' @param left: default is "["]
#' @param right: defualt is ")"
#' @param sep the separator between the left and right interval boundaries: default is \code{"_"}.
#'
#' @examples
#' int_labels( c(0.25,0.5))
#' int_labels( c(0.25,0.5),lower=0,upper=1)
#' int_labels( c(0.25,0.5),lower=0,upper=1,left="",right="",sep=" to ")
#'
int_labels = function(cutoffs,
                      lower = NULL,
                      upper = NULL,
                      left = "[",
                      right = ")",
                      sep = "_") {

  n.int = length(cutoffs) + 1

  cutoffs1 = c(lower, cutoffs, upper)
  n.int1 = length(cutoffs1) + 1

  if (n.int1 > 2)
    int.labels = paste(left,cutoffs1[1:(n.int1-2)],sep,cutoffs1[2:(n.int1-1)],right,sep="")
  else
    int.labels = NULL

  first.label = NULL
  if (is.null(lower))
    first.label = paste("<", cutoffs[1], sep = "")
  last.label = NULL
  if (is.null(upper))
    last.label = paste(">=", cutoffs[n.int - 1], sep ="")

  int.labels = c(first.label, int.labels, last.label)

  return(int.labels)
}

