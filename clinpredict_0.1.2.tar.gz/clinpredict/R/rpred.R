#' Predictive simulations using non-parametric predictive distribution by Hill
#'
#' @param n.sim number of simulations
#' @param x data vector
#' @param low lower bound for data
#' @param up upper bound for data
#'
#' @examples
#' x = c(1,4,5,12)
#' pred = rpred(n.sim=1e5,x=x)
#' sim_sum(pred)
#' # compare to analytic summaries
#' spred(x=x)
#' 
rpred = function(n.sim=1,x,low=-Inf,up=+Inf) {
  # use of inversion method
  return( qpred(runif(n.sim),
                    x=x,low=low,up=up
  )
  )
}


