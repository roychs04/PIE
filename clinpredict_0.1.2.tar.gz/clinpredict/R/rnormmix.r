#' Random numbers from mixture of normal distributions
#'
#' random numbers for a mixture of normal distributions
#'
#' @param n.sim number of simulated values
#' @param wms a list, matrix, or vector of values that specify the mixture distribution: a and b refer to the mean and standard deviation.
#'
#' @examples
#' y = rnormmix(list(c(1,10,1),c(1,1,4)),n.sim=1e5)
#' hist(y)
#'
rnormmix = function(n.sim = 1, wms) {
  wms = mix_pars(wms)

  comp = sample(1:wms$k,
                size = n.sim,
                replace = TRUE,
                prob = wms$w)
  sim = rnorm(n.sim, wms$a[comp], wms$b[comp])
  return(sim)
}
