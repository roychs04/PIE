#' Simple barplot function
#'
#' @param y n-vector of values to be displayed in barplot
#' @param group n-vector of grouping variable values
#' @param subgroup n-vector of subgrouping variable values (optional)
#' @param xlab x-axis label
#' @param ylab y-axis label
#' @param title plot title
#' @param show.legend logical: if \code{TRUE}, a legend of subgroup
#' values will be shown
#' @param text.size text size; default is 18
#'
#' @examples
#'
#' plot_bar( y=c(2,5,3),group=c("B","A","C"))
#' # Note the ordering!
#' plot_bar( y=c(2,5,3),group=factor(c("B","A","C"),levels=c("B","A","C")))
#' plot_bar( y=c(2,5,3,1,4,2),
#'           group=c("A","A","B","B","C","C"),
#'           subgroup=rep(c(1,2),3))
#' plot_bar( y=c(2,5,3,1,4,2),
#'           group=c("A","A","B","B","C","C"),
#'           subgroup=rep(c(1,2),3),col.subgroup=c("green","blue"))
#'
plot_bar = function(y,
                    group,
                    subgroup=NULL,
                    xlab="",
                    ylab="",
                    title="",
                    show.legend=TRUE,
                    text.size,
                    col.subgroup=NULL,
                    ylim=NULL)
{

  if (is.null(subgroup)) {
    ds = data.frame(y=y,x=group)
    fig =
      ggplot( data=ds,aes(x=x,y=y))+
      geom_bar(position="dodge",stat="identity")+
      xlab(xlab)+
      ylab(ylab)+
      ggtitle(title)

    if (!missing(text.size))
      fig = fig+
        theme(text=element_text(size=text.size))
  }

  if (!is.null(subgroup)) {
    subgroup = as.factor(subgroup)
    ds = data.frame(y=y,x=group,subgroup=subgroup)
    fig =
      ggplot( data=ds,aes(x=x,y=y,fill=subgroup))+
      geom_bar(position="dodge",stat="identity",show.legend=show.legend)+
      xlab(xlab)+
      ylab(ylab)+
      ggtitle(title)

      if (!is.null(col.subgroup))
        fig = fig+
      scale_fill_manual(values = col.subgroup)

      if (!missing(text.size))
        fig = fig +
      theme(text=element_text(size=text.size))
  }

  fig = fig + theme_classic()

  if (!is.null(ylim))
    fig = fig +  ylim(ylim)

  fig = fig +
    theme(axis.title.x = element_text(size=rel(1.5))) +
    theme(axis.title.y = element_text(size=rel(1.5)))

  return(fig)
}


