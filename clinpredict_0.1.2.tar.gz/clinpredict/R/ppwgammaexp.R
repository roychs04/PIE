
#' Distribution function of gamma-exponential distribution
#'
#' @param q vector of quantiles
#' @param a vector of interval-specific a parameters
#' @param b vector of interval-specific b parameters
#' @param int *vector of interval boundaries
#'
#' @examples
#'
ppwgammaexp = function(q, a, b, int) {
  int0 = c(0, int)
  n.int = length(int0)
  L = diff(int0)

  if (length(a) != n.int)
    stop("Length of a-vector bust be *n.int*")

  if (length(b) != n.int)
    stop("Length of b-vector bust be *n.int*")

  surv = rep(1, length(q))
  for (j in 1:(n.int - 1)) {
    sel = (q >= int0[j] & q < int0[j + 1])
    surv[sel] = surv[sel] * (1 - pgammaexp((q[sel] - int0[j]), a[j], b[j]))
    sel = (q >= int0[j + 1])
    surv[sel] = surv[sel] * (1 - pgammaexp(L[j], a[j], b[j]))
  }

  sel = q > int0[n.int]
  if (any(sel))
    surv[sel] = surv[sel] * (1 - pgammaexp(q[sel] - int0[n.int], a[n.int], b[n.int]))

  out = 1 - surv
  names(out) = q
  return(out)
}



