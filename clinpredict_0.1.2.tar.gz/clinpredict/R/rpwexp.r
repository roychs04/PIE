#' Random numbers from a piecewise exponential distribution
#'
#' @param n.sim number of simulations
#' @param lambda \code{n.int}-vector or \code{sxn.int} matrix of interval hazards
#' @param int \code{n.int-1}-vector of interval boundaries
#'
#' @examples
#' int = c(1,2)
#' lambda1 = c(1,2,3)
#' lambda2 = lambda1*0.01
#' rpwexp(lambda=lambda1,int=c(1,2))
#' rpwexp(n.sim=5,lambda=lambda1,int=c(1,2))
#' rpwexp(lambda=rbind(lambda1,lambda2),int=c(1,2))
#'
rpwexp = function(n.sim, lambda, int) {

  check_lambdaint(lambda, int)

  if (is.matrix(lambda) & !missing(n.sim))
    if (n.sim != nrow(lambda))
      stop("n.sim must equal the number of lambdas (number of rows in *lambda* matrix)")

  int0 = c(0, int)
  n.int = length(int0)
  L = diff(int0)
  L = c(L, 1e12)
  int0 = c(int0, Inf)

  if (is.vector(lambda)) {
    if (is.vector(lambda) & missing(n.sim))
      n.sim = 1
  }

  if (is.matrix(lambda)) {
    if (missing(n.sim))
      n.sim = nrow(lambda)
  }

  if (!is.matrix(lambda))
    lambda = matrix(lambda, n.sim, n.int, byrow = TRUE)

  n.sim = nrow(lambda)

  x = 0
  surv = 1
  event = 0
  for (j in 1:n.int) {
    xj = rexp(n.sim, lambda[, j])
    eventj = xj < L[j]
    x = x + xj * (!event & eventj) + L[j] * (!event &
                                               !eventj) + 0 * event
    event = (event | eventj)
  }
  return(x)
}
