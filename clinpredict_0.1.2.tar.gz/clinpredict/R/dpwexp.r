#' Density of piecewise exponential distribution
#'
#' @param lambda \code{n.int}-vector or \code{sxn.int} matrix of interval hazards
#' @param int \code{n.int-1}-vector of interval boundares
#'
#' @examples
#' #interval boundaries
#' int = c(10,25,50,100)
#' #hazards by interval
#' lambda = c(2,5,10,20,10)/100
#' x = seq(0,100,by=0.1)
#' plot(x,dpwexp(x,lambda,int),lwd=2,type="l",main="density")
#' abline(v=int,lty=3)
#'
dpwexp = function(x, lambda, int) {

  check_lambdaint(lambda, int)

  int0 = c(0, int)
  n = length(x)
  int.k = length(lambda)
  L = diff(int0)[1:int.k]
  L[int.k] = 0
  int.ix = sapply(int0, function(e)
    x >= e)
  int.ix = int.ix %*% rep(1, int.k)
  int.ix[int.ix == 0] = 1
  cumhaz = rep(0, n)
  for (j in 1:int.k) {
    cumhaz = cumhaz + lambda[j] * L[j] * (int.ix > j) + lambda[j] * (x - int0[j]) *
      (int.ix == j)
  }
  d = exp(-cumhaz) * lambda[int.ix]
  return(d)
}
