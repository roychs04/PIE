
#' Random numbers from gamma-exponential distribution
#'
#' @param n.sim number of simulations
#' @param a vector of interval-specific a parameters
#' @param b vector of interval-specific b parameters
#' @param int *vector of interval boundaries
#'
rpwgammaexp = function(n.sim, a,b, int) {

  int0 = c(0, int)
  n.int = length(int0)
  L = diff(int0)
  L = c(L, 1e12)
  int0 = c(int0, Inf)

  if (length(a) != n.int)
    stop("Length of a-vector bust be *n.int*")

  if (length(b) != n.int)
    stop("Length of b-vector bust be *n.int*")

  x = 0
  surv = 1
  event = 0
  for (j in 1:n.int) {
    xj = rgammaexp(n.sim, a[j],b[j])
    eventj = xj < L[j]
    x = x + xj * (!event & eventj) + L[j] * (!event &
                                               !eventj) + 0 * event
    event = (event | eventj)
  }
  return(x)
}


