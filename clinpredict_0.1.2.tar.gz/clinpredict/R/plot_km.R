#' Kaplan-Meier survival curves
#'
#' @param data The dataframe, which must have the following variables: 
#' \code{time} (survival or censoring times), 
#' \code{event} (event indicators: 1 for survival times, 0 for censoring times). For 
#' more than one treatment, the variable \code{group} must be in the dataframe as well.
#' @param col color for the \code{k} treatments
#' @param lty 2-vector with linetype for survival curves and confidence intervals
#' @param lwd 2-vector with linewidth for survival curves and confidence intervals
#' @param xlab 
#' @param ci logical: \code{TRUE} to show confidence intervals, \code{FALSE} otherwise
#' @param time.unit 
#'
#' @examples
#' 
plot_km = function(data,
                   col = c("red","blue"),
                   lty = c(1,3),
                   lwd=c(1,0.5),
                   ylab="survival rate",
                   xlab="",
                   ci = TRUE,
                   time.unit="") {

  if (is.element("group",names(data))) {
    groups = sort(unique(data$group))
    n.groups = length(groups)
  }
  else {
    n.groups=1
    groups=1
    data$group=1
  }
    
  data.j = list()
  # survival fits
  sf = list()
  
  for (j in 1:n.groups) {
    data.j[[j]] = data %>% filter(group==groups[j])
    sf[[j]] = survfit(Surv(time,event) ~ 1, data = data.j[[j]])
    sf[[j]] = data.frame(
      time=sf[[j]]$time,
      surv=sf[[j]]$surv,
      lower=sf[[j]]$lower,
      upper=sf[[j]]$upper,
      group=as.character(groups[j])
      )
  }
  
  data.all = NULL
  for (j in 1:length(sf)) data.all = rbind(data.all,sf[[j]])
  

  pl = ggplot(data=data.all,aes(x=time,y=surv,colour=group),size=lwd[1])+
    geom_line()
  
  
  if (ci) {
    for (j in 1:n.groups){
        pl = pl+
          geom_line(data=sf[[j]],aes(x=time,y=lower),col=col[j],linetype=lty[2],size=lwd[2])+
          geom_line(data=sf[[j]],aes(x=time,y=upper),col=col[j],linetype=lty[2],size=lwd[2])
    }
  }

  
  if (time.unit=="") xlab1 = xlab
  if (time.unit!="") {
    xlab1 = paste(xlab,
                  ifelse(xlab=="",
                         time.unit,
                         paste(" (",time.unit,")",sep=""))
    )
  }
  
  
    # pl = pl + 
    #   theme_gray()
    pl = pl +
      scale_colour_manual(values=col)+
    ylim(c(0,1))+
    ylab(ylab)+
    xlab(xlab1)
    
    
    if (n.groups>1) 
      pl = pl+
      theme(legend.title=element_blank(),
            legend.position = "top"
      )
    
    if (n.groups==1) 
      pl = pl+
      theme(legend.title=element_blank(),
            legend.position = NULL
      )
  
  return(pl)
}

# # 
# # 
# library(tidyverse)
# library(survival)
# source("Data_tafamidis.r")
# 
# 
# data = tafamidis
# data$group = data$trt1
# 
# 
# pp = plot_km(data,ci=TRUE,col=c("grey","darkgrey"))
# pp

 # data1 = data %>% 
 #   select(time,event)
 
# head(data1)
# pp1 = plot_km(data1,col="green",ci=TRUE,
#               time.unit="month")
# pp1
