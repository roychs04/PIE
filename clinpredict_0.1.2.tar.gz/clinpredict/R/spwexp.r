#' Summaries of piecewise-exponential distribution
#'
#' @param lambda \code{n.int}-vector or \code{sxn.int} matrix of interval hazards
#' @param int \code{n.int-1}-vector of interval boundares
#' @param probs scalar or vector of probabilities for which quantiles will be giv@en
#' @param cutoffs cutoff values defining intervals
#'
#' @examples
#' int = c(10,25,50,100)
#' lambda = c(10,5,10,20,5)/100
#' rrr = rpwexp(2e6,lambda,int)
#' cat("summaries from simulation \n")
#' print(c( mean=mean(rrr), sd=sd(rrr), quantile(rrr,c(0.025,0.5,0.975)) ))
#' cat("exact \n")
#' print(round(spwexp(lambda,int),3))
#'
spwexp = function(lambda,
                  int,
                  probs = c(0.025, 0.5, 0.975),
                  cutoffs = NULL) {
  # mean of truncated (0,t) exponential distribution
  # 1/lambda - t x exp(-t x lambda) / (1-exp(-t x lambda))
  # 2nd moment: 2*mean-t^2 x exp(-t x lambda) / (1-exp(-t x lambda))
  # Note that interval boundary shifts are needed

  check_lambdaint(lambda, int)

  lambdaAll = rbind(lambda)
  sumAll = NULL

  for (jj in 1:nrow(lambdaAll)) {
    lambda = lambdaAll[jj, ]

    k = length(lambda)
    k1 = k - 1
    p = ppwexp(int, lambda, int)

    pp = c(p, 1) - c(0, p)
    LL = int - c(0, int[-length(int)])
    mint = 1 / lambda[1:k1] - LL[1:k1] * exp(-lambda[1:k1] * LL[1:k1]) / (1 -
                                                                            exp(-lambda[1:k1] * LL[1:k1]))
    LL1 = LL[1:k1]
    lambda1 = lambda[1:k1]

    TT0 = c(0, int[-length(int)])
    TT1 = max(int)
    x2int = 2 / lambda1 * mint - LL1 ^ 2 * exp(-lambda1 * LL1) / (1 - exp(-lambda1 *
                                                                            LL1))
    x2 = x2int + 2 * TT0 * mint + TT0 ^ 2

    mint.last = 1 / lambda[k]
    mint = c(mint, mint.last)


    x2.last = 2 / lambda[k] ^ 2 + 2 * mint.last * TT1 + TT1 ^ 2
    x2 = c(x2, x2.last)

    mn = sum(pp * (mint + c(0, int)))

    vr = sum(pp * x2) - mn ^ 2
    sd = sqrt(vr)
    qntls = qpwexp(probs,lambda, int)

    out = c(mn, sd, qntls)
    names(out) = c("mean", "sd", probs)

    # threshold (cutoffs) probabilities
    if (!is.null(cutoffs)) {
      cutoffs.labels = int_labels(cutoffs, lower = 0, upper = NULL)
      p.cut = sapply(cutoffs, function(e)
        ppwexp(e, lambda, int))
      p.cut = c(0, p.cut, 1)
      p.cut = diff(p.cut)
      names(p.cut) = cutoffs.labels
      out = c(out, p.cut)
    }
    sumAll = rbind(sumAll, out)
  }
  if (nrow(lambdaAll) == 1)
    sumAll = sumAll[1, ]
  else
    rownames(sumAll) = paste("lambda", 1:nrow(lambdaAll), sep = "")

  return(sumAll)
}
