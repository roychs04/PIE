#' Summaries of a mixture of Beta  distributions
#'
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distribution
#' @param probs vector of probabilities for which quantiles will be giv@en
#' @param cutoffs cutoff values defining intervals
#'
#' @examples
#' sbeta(3,7)
#' sbetamix(c(3,7))
#' sbetamix( list(c(0.9,3,7),c(0.1,1,1)),cutoffs=c(0,0.5,1))
#'
#'
sbetamix = function(wab,
                    probs = c(0.025, 0.5, 0.975),
                    cutoffs = NULL
                    ) {
  wab = mix_pars(wab)
  mns = wab$a / (wab$a + wab$b)
  mn = sum(wab$w * mns)
  vrs = wab$a * wab$b / (wab$a + wab$b) ^ 2 / (wab$a + wab$b + 1)
  vr = sum(wab$w * vrs) + sum(wab$w * (mns - mn) ^ 2)
  sd = sqrt(vr)

  qntls = qbetamix(probs, wab$L)

  out = c(mn, sd, qntls)
  names(out) = c("mean", "sd", probs)

  if (!is.null(cutoffs)) {
    # threshold (cutoff) probabilities
    if (!is.null(cutoffs)) {
      cutoffs.labels=int_labels(cutoffs,lower=0,upper=1)
      p.cut = sapply(cutoffs, function(e)
        pbetamix(e, wab$L))
      p.cut = c(0,p.cut,1)
      p.cut = diff(p.cut)
      names(p.cut) = cutoffs.labels
      out = c(out, p.cut)
    }
  }

  return(out)
}
