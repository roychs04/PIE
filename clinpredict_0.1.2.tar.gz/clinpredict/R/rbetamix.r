#' Random numbers from mixture of beta distributions
#'
#' @param n.sim number of simulated values
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distributionwab
#'
#' @examples
#' rb = rbetamix(list(c(1,10,1),c(1,1,4)),n.sim=1e5)
#' hist(rb)
#'
rbetamix = function(n.sim = 1, wab) {
  wab = mix_pars(wab)
  comp = sample(1:wab$k,
                size = n.sim,
                replace = TRUE,
                prob = wab$w)
  sim = rbeta(n.sim, wab$a[comp], wab$b[comp])
  return(sim)
}
