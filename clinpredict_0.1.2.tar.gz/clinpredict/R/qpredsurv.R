
#' Predictive quantile function using non-parametric Berliner-Hill predictive distribution
#'
#' @param probs vector of probabilities
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators, 1 for events and 0 for censored observations. If \code{NULL},
#' no censoring is assumed
#' @param version original version ("BerlinerHill") or modified version ("pwgammaexp")
#'
#' @examples
#' data(km)
#' qpredsurv(time=km$time,event=km$event)
#' qpredsurv(time=km$time,event=km$event,version="BerlinerHill")
#'
qpredsurv = function(p=c(0.025,0.5,0.975),time,event=NULL,
                     version=c("BerlinerHill","pwgammaexp")[2]) {

  probs = p
  # for rightcensored data
  if (is.null(event))
    event = rep(1,length(time))

  if (version=="BerlinerHill") {
    a = cpdfsurv(time,event,version=version)
    cpdf = a$cpdf
    lambda = a$lambda
    int = a$int

    time.pred = qpwexp(probs,lambda=lambda,int=int)
    time.pred = as.vector(time.pred)
  }
  if (version=="pwgammaexp") {
    aa = cpdfsurv(time,event,version=version)
    cpdf = aa$cpdf
    a = aa$a
    b = aa$b
    int = aa$int

    time.pred = qpwgammaexp(probs,a,b,int=int)
    time.pred = as.vector(time.pred)
  }

  names(time.pred) = signif(probs,3)

  return(time.pred)
}


