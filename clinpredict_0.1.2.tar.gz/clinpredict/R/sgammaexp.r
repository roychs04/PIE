#' Summaries of Gamma-Exponential distribution
#'
#' @param a,b parameters of gamma-exponential distribution
#' @param probs vector of probabilities for which quantiles will be giv@en
#' @param cutoffs cutoff values defining intervals
#'
#' @examples
#' a=c(0.5,1.5,2.5); b=10
#' print(sgammaexp(a,b,cutoffs=10))
#' sim_sum(rgammaexp(n.sim=1e6,a=a[3],b=b))
#
sgammaexp <-
  function(a,
           b,
           probs = c(0.025, 0.5, 0.975),
           cutoffs = NULL) {

    a = 0 * b + a
    b = 0 * a + b

    ab = cbind(a,b)

    mn = b / (a - 1)
    mn[a<=1] = NA

    vr = a * b^2  / (a - 1) ^ 2 / (a - 2)
    vr[a<=2] = NA
    sd = sqrt(vr)

    qntls = apply(ab, 1, function(e)
      qgammaexp(probs, e[1], e[2]))

    if (length(probs) > 1)
      qntls = t(qntls)

    out = cbind(mn, sd, qntls)
    colnames(out) = c("mean", "sd", probs)

    # threshold (cutoff) probabilities
    if (!is.null(cutoffs)) {
      cutoffs.labels = int_labels(cutoffs,lower=0,upper=NULL)
      p.cut = sapply(cutoffs, function(e)
        pgammaexp(e, a, b))
      p.cut = matrix(p.cut,ncol=length(cutoffs))
      p.cut = cbind(0,p.cut,1)
      p.cut = t(apply(p.cut,1,diff))
      p.cut = cbind(p.cut)
      colnames(p.cut) = cutoffs.labels
      out = cbind(out, p.cut)
    }
    if (nrow(out) == 1)
      out = out[1,]

    return(out)
  }
