#' Simulation of a random vector from the non-parametric Berliner-Hill predictive distribution
#'
#' @param n.sim Number of simulations
#' @param m dimension of vector; for \code{m=1}, use the
#' \code{rpredsurv} function
#' @param time n-vector of event or censoring times
#' @param event n-vector of indicators, 1 for events and 0 for censored observations. If \code{NULL},
#' no censoring is assumed
#'
#' @examples
#' data(km)
#' time = km$time
#' event = km$event
#' pred = rmultipredsurv(n.sim=1000,m=5,time=km$time,event=km$event)
#' cor.pred = cor(pred)
#' # of interest: sum of the next 5 predictions
#' pred = apply(pred,1,sum)
#' cor.pred
#'
rmultipredsurv = function(n.sim = 1,
                      m,
                      time,
                      event = NULL) {
  if (is.null(event))
    event = rep(1, length(time))

  predall = sapply(1:n.sim, function(e) {
    pred = rep(NA, m)
    for (mm in 1:m) {
      new = rpredsurv(1, time = time, event = event)
      pred[mm] = new
      time = c(time, new)
      event = c(event, 1)
    }
    return(pred)
  })
  if (n.sim > 1)
    predall = t(predall)

  return(predall)
}



