#' Cumulative distribution function for piecewise-exponential model
#'
#' @param q a vector of quantiles
#' @param lambda \code{n.int+1}-vector or \code{k x n.int+1} matrix of exponential parameters
#' @param int \code{n.int}-vector of interval boundaries
#' @param simsum logical: if \code{TRUE}, simulation summaries will be given (defaults to \code{FALSE})
#'
#'
#' @examples
#' # two intervals
#' int = 3
#' # single parameter vector
#' lambda1 = c(0.1,0.2)
#' x=c(1,3,5,10)
#' ppwexp(x,lambda1,int)
#' r = rpwexp(1e5,lambda1,int)
#' sapply(x,function(e) mean(r<=e))
#'
#' # two parameter vectors
#' lambda2 = c(0.09,0.22)
#' lambda = rbind(lambda1,lambda2)
#' ppwexp(x,lambda,int)
#' ppwexp(x,lambda1,int)
#' ppwexp(x,lambda2,int)
#'
#' # simulation sample of lambda parameters
#' lambda.sim = cbind(runif(1e4,0.09,0.11),runif(1e4,0.15,0.20))
#' ppwexp(x,lambda.sim,int,simsum=TRUE)
#'
ppwexp = function(q,
                  lambda,
                  int,
                  simsum=FALSE) {

  check_lambdaint(lambda, int)

  int0 = c(0, int)
  n.int = length(int0)
  L = diff(int0)

  if (is.vector(lambda)) {
    surv = rep(1, length(q))
    for (j in 1:(n.int - 1)) {
      sel = (q >= int0[j] & q < int0[j + 1])
      surv[sel] = surv[sel] * exp(-lambda[j] * (q[sel] - int0[j]))
      sel = (q >= int0[j + 1])
      surv[sel] = surv[sel] * exp(-lambda[j] * L[j])
    }

    sel = q > int0[n.int]
    if (any(sel))
      surv[sel] = surv[sel] * (exp(-lambda[n.int] * (q[sel] - int0[n.int])))

    out = 1 - surv
    names(out) = q
    if (simsum)
      out = sim_sum(out)
  }


  if (is.matrix(lambda)) {

    out = matrix(NA,nrow(lambda),length(q))

    for ( jj in 1:length(q)) {
      surv = rep(1,nrow(lambda))

      for (j in 1:(n.int - 1)) {
        sel = (q[jj] >= int0[j] & q[jj] < int0[j + 1])
        if (sel)
          surv = surv * exp(-lambda[,j] * (q[jj] - int0[j]))
        sel = (q[jj] >= int0[j + 1])
        if (sel)
          surv = surv * exp(-lambda[,j] * L[j])
      }

      sel = q[jj] > int0[n.int]
      if (sel)
        surv = surv * (exp(-lambda[,n.int] * (q[jj] - int0[n.int])))

      out[,jj] = 1 - surv
    }

    colnames(out) = q
    if (simsum)
      out = sim_sum(out)
  }

  return(out)
}

