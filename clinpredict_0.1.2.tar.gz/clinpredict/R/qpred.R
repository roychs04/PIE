
#' Predictive quantile function using non-parametric predictive distribution by Hill
#'
#' @param probs vector of probabilities
#' @param x data vector
#' @param low lower bound for data
#' @param up upper bound for data
#'
#' @return vector of quantiles
#'
#' @examples
#' x = c(1,4,5,12)
#' qpred(x=x)
#' qpred(0.5,x=x)

qpred = function(p = c(0.025, 0.5, 0.975),
                 x,
                 low = -Inf,
                 up = +Inf) {
  x = sort(x)
  probs = p

    if (low != -Inf & up != +Inf) {
      cpdf = cpdf(x)
      x = cpdf$int
      cpdf = cpdf$cpdf
      q.pred = approx(c(0, cpdf, 1), c(low, x, up), xout = probs)$y
    }


    if (low == -Inf & up == +Inf) {

      cpdf = cpdf(x)
      x = cpdf$int
      cpdf = cpdf$cpdf


      q.pred = approx(x=cpdf,y=x,xout=probs)$y

      ms = get_ms(
        lower = min(x),
        upper = max(x),
        probs = c(min(cpdf), max(cpdf)),
        distribution = "normal"
      )
      p.tail = probs[probs < min(cpdf) | probs > max(cpdf)]
      x.tail = qnorm(p.tail, ms[1], ms[2])
      q.pred[is.na(q.pred)] = x.tail
    }

    if (low == 0 & up == +Inf) {
      q.pred = qpredsurv(probs,time=x,event=NULL)
    }

    names(q.pred) = signif(probs, 2)

  return(q.pred)
}


