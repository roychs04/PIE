#' Quantiles of mixture of gamma distributions
#'
#' @param p vector of probabilities
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distributionwab
#'
#' @examples
#'
#' wab = list(c(0.2,6,2), c(0.8,25,3))
#' p = 0.75
#' q = qgammamix( p, wab)
#' print(q)
#' # check
#' print( pgammamix(q,wab))
#' curve( pgammamix(x,wab),type="l",lwd=2)
#' abline(h=p,lty=3)
#' abline(v=q,lty=3)
#'
qgammamix = function(p = c(0.025, 0.5, 0.975),
                     wab,
                     eps = 1e-5) {
  q = 0 + p
  r = rgammamix(1e5, wab)
  for (j in 1:length(p)) {
    x.low = quantile(r, 0.9 * p[j])
    x.high = quantile(r, 1 - 0.9 * (1 - p[j]))
    x.grid = seq(x.low, x.high, by = eps)
    ppp = pgammamix(x.grid, wab)
    iii = which.min(abs(ppp - p[j]))
    q[j] = x.grid[iii]
  }
  names(q) = p
  return(q)
}
