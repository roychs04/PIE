#' Summary statistics for simulations
#'
#' @param x the simulation output matrix; each column corresponds to a variable
#' @param probs the probabilities defining the quantiles
#' @param cutoffs cutoff values defining intervals
#' @param min.max logical: if \code{TRUE}, minimum and maximum are shown
#' @param n.sim logical: if \code{TRUE}, the number of simulations is shown
#' @param na.rm logical: if \code{TRUE}, missing values will be removed
#'
#' @return the table of simulation summaries, with as many rows as there are variables
#'
`sim_sum` <- function(x,
                      probs = c(0.025, 0.5, 0.975),
                      cutoffs = NULL,
                      min.max = F,
                      n.sim = F,
                      na.rm = FALSE)
{
  x <- cbind(x)
  nsim = nrow(x)

  out <- apply(x, 2, function(r)
    c(
      mean(r, na.rm = na.rm),
      sqrt(var(r, na.rm = na.rm)),
      quantile(r, probs, na.rm = na.rm)
    ))
  out = t(out)
  colnames(out) =
    c("mean",
      "sd",
      paste(round(100 * probs, 1), "%", sep = ""))


  int.probs = NULL
  if (!is.null(cutoffs)) {
    xint = apply(x, 2, function(e)  findInterval(e,cutoffs))
    int.probs = apply(xint,2,function(e) sapply(0:length(cutoffs+1),function(ee) mean(e==ee) ))
    int.probs = t(int.probs)
    int.probs = rbind(int.probs)
    colnames(int.probs) = int_labels(cutoffs)
  }

  out = cbind(out, int.probs)

  mima = NULL
  if (min.max) {
    mima = t(apply(x, 2, range, na.rm = na.rm))
    mima = cbind(mima)
    colnames(mima) = c("min", "max")
  }

  out = cbind(out, mima)

  if (n.sim)
    out = cbind(out, nsim)


  if (nrow(x)>1)
    rownames(out) = colnames(x)

  return(out)
}
