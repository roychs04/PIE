spwgammaexp = 
function (a, b, int, probs = c(0.025, 0.5, 0.975)) 
{
  int0 = c(0, int)
  n.int = length(int0)
  if (length(a) != n.int) 
    stop("Length of a-vector bust be *n.int*")
  if (length(b) != n.int) 
    stop("Length of b-vector bust be *n.int*")
  
  qntls = qpwgammaexp(probs, a, b, int)

  mn = NA;  sd = NA
  if (all(a>1))  {
    y = rpwgammaexp(1e+06, a, b, int)
    names(qntls) = probs
    if (all(a > 1)) 
      mn = mean(y)
    if (all(a > 2)) 
      sd = sd(y)
  }
 out = c(mean = mn, sd = sd, qntls)
  return(out)
}