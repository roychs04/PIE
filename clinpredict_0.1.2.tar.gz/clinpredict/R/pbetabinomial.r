#' Cumulative distribution function (cdf) of beta-binomial distribution
#'
#' beta-binomial (overdispersed binomial) distribution function:
#' theta ~ beta(a,b), Y | theta ~ binomial(theta,n), Y ~ beta-binomilal(n,a,b)
#'
#' @param r number of successes for which the cdf will be computed
#' @param n sample size
#' @param a,b  parameters of Beta distribution
#'
#' @examples
#' pbetabinomial(0:4,4,1,1)
#'
pbetabinomial <- function(r, n, a, b) {
  out = sapply(r, function(e) {
    rr <- seq(0, e)
    p = sum(dbetabinomial(rr, n, a, b))
    return(p)
  })
  return(out)
}
