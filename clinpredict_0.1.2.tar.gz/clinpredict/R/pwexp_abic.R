

#' Akaike and Bayesian information criterion for piecewise-exponential data
#'
#' @param time n-vector of event and censoring times
#' @param event n-vector of event indicators: 1 for 
#' event time, 0 for censoring time
#' @param int vector of interval boundaries; \code{NULL},
#' for exponential distribution
#'
#' @return
#' the AIC and BIC values

pwexp_abic = function(time, event, int=NULL) {
  if (is.null(int))
    n.int = 1
  if (!is.null(int))
    n.int = length(int) + 1
  
  if (n.int > 1) {
    dss = ipd2int(obstime = time,
                  event = event,
                  int = int)
    aic = -2 * (sum(log(dss$haz) * dss$nevents - dss$haz * dss$exptime)) +
      2 * n.int
    bic = -2 * (sum(log(dss$haz) * dss$nevents - dss$haz * dss$exptime)) +
      log(length(time)) *n.int
  }
  if (n.int == 1) {
    haz = sum(event) / sum(time)
    aic = -2 * (log(haz) * sum(event) - haz * sum(time)) + 2 * n.int
    bic = -2 * (log(haz) * sum(event) - haz * sum(time)) + 
      log(length(time)) *n.int
  }
  
  out = list(aic=aic,bic=bic)
  return(out)
}






