#' Summaries of a mixture of Gamma distributions
#'
#' @param wab a list, matrix, or vector of values that specify the (mixture) probability distribution
#' @param probs vector of probabilities for which quantiles will be obtained
#' @param cutoffs cutoff values defining intervals
#' @param plot logical: \code{TRUE} to show density plots. Use \code{plot_beta} for better control of plots
#'
#' @return a vector of summary statistics: mean, standard deviations, variance, and quantiles
#'
#' @examples
#' sgamma(1,1)
#' sgammamix( list(c(0.5,1,1),c(0.5,2,20)),cutoffs=c(0.5,1),plot=TRUE)
#'
sgammamix = function(wab,
                     probs = c(0.025, 0.5, 0.975),
                     cutoffs = NULL,
                     plot = FALSE) {
  if (plot)
    plot_gammamix(wab,probs=probs)

  wab = mix_pars(wab)
  mns = wab$a / wab$b
  mn = sum(wab$w * mns)
  vrs = wab$a / wab$b ^ 2
  vr = sum(wab$w * vrs) + sum(wab$w * (mns - mn) ^ 2)
  sd = sqrt(vr)
  cv = sd / mn
  qntls = qgammamix(probs, wab$L)

  out = c(mn, sd, qntls)
  names(out) = c("mean", "sd", probs)


  if (!is.null(cutoffs)) {
    cutoffs.labels = int_labels(cutoffs,lower=0,upper=NULL)
    p.cut = sapply(cutoffs, function(e)
      pgammamix(e, wab$L))
    p.cut = c(0, p.cut, 1)
    p.cut = diff(p.cut)
    names(p.cut) = cutoffs.labels
    out = c(out, p.cut)
  }

  return(out)
}
